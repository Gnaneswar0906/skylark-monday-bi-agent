import {
  normalizeText,
  normalizeSector,
  normalizeDate,
  normalizeNumeric,
  normalizeProbability,
  normalizeProbabilityLabel,
  normalizeDealStatus,
  normalizeDealStage,
  normalizeExecutionStatus,
} from '../../lib/data/normalize'

describe('normalizeText', () => {
  test('trims whitespace', () => {
    expect(normalizeText('  Mining  ')).toBe('Mining')
  })
  test('title-cases lowercase', () => {
    expect(normalizeText('mining')).toBe('Mining')
  })
  test('handles ALL CAPS', () => {
    expect(normalizeText('MINING')).toBe('Mining')
  })
  test('returns null for empty string', () => {
    expect(normalizeText('')).toBeNull()
  })
  test('returns null for dash', () => {
    expect(normalizeText('-')).toBeNull()
  })
  test('returns null for n/a', () => {
    expect(normalizeText('n/a')).toBeNull()
  })
  test('returns null for null input', () => {
    expect(normalizeText(null)).toBeNull()
  })
})

describe('normalizeDate', () => {
  test('parses ISO date', () => {
    expect(normalizeDate('2025-12-26')).toBe('2025-12-26')
  })
  test('parses yyyy-MM-dd', () => {
    expect(normalizeDate('2026-02-26')).toBe('2026-02-26')
  })
  test('returns null for empty string', () => {
    expect(normalizeDate('')).toBeNull()
  })
  test('returns null for null', () => {
    expect(normalizeDate(null)).toBeNull()
  })
  test('returns null for invalid date', () => {
    expect(normalizeDate('not-a-date')).toBeNull()
  })
})

describe('normalizeNumeric', () => {
  test('parses plain number', () => {
    expect(normalizeNumeric('125000')).toBe(125000)
  })
  test('strips currency symbol', () => {
    expect(normalizeNumeric('₹1,25,000')).toBe(125000)
  })
  test('strips commas', () => {
    expect(normalizeNumeric('1,25,000')).toBe(125000)
  })
  test('handles numeric type input', () => {
    expect(normalizeNumeric(489360)).toBe(489360)
  })
  test('returns null for empty string', () => {
    expect(normalizeNumeric('')).toBeNull()
  })
  test('returns null for null', () => {
    expect(normalizeNumeric(null)).toBeNull()
  })
  test('returns null for non-numeric string', () => {
    expect(normalizeNumeric('abc')).toBeNull()
  })
})

describe('normalizeProbability', () => {
  test('converts High to 0.75', () => {
    expect(normalizeProbability('High')).toBe(0.75)
  })
  test('converts Medium to 0.5', () => {
    expect(normalizeProbability('Medium')).toBe(0.5)
  })
  test('converts Low to 0.25', () => {
    expect(normalizeProbability('Low')).toBe(0.25)
  })
  test('parses percentage string', () => {
    expect(normalizeProbability('70%')).toBeCloseTo(0.7)
  })
  test('parses decimal probability', () => {
    expect(normalizeProbability('0.7')).toBe(0.7)
  })
  test('returns null for empty', () => {
    expect(normalizeProbability('')).toBeNull()
  })
  test('returns null for null', () => {
    expect(normalizeProbability(null)).toBeNull()
  })
})

describe('normalizeProbabilityLabel', () => {
  test('returns High', () => {
    expect(normalizeProbabilityLabel('High')).toBe('High')
  })
  test('returns Medium', () => {
    expect(normalizeProbabilityLabel('medium')).toBe('Medium')
  })
  test('returns null for unknown', () => {
    expect(normalizeProbabilityLabel('Unknown')).toBeNull()
  })
})

describe('normalizeDealStatus', () => {
  test('open', () => { expect(normalizeDealStatus('Open')).toBe('Open') })
  test('won', () => { expect(normalizeDealStatus('Won')).toBe('Won') })
  test('lost', () => { expect(normalizeDealStatus('Lost')).toBe('Lost') })
  test('on hold', () => { expect(normalizeDealStatus('On Hold')).toBe('On Hold') })
  test('unknown', () => { expect(normalizeDealStatus('Pending')).toBe('Unknown') })
  test('null returns Unknown', () => { expect(normalizeDealStatus(null)).toBe('Unknown') })
})

describe('normalizeExecutionStatus', () => {
  test('Completed', () => { expect(normalizeExecutionStatus('Completed')).toBe('Completed') })
  test('Not Started', () => { expect(normalizeExecutionStatus('Not Started')).toBe('Not Started') })
  test('Ongoing', () => { expect(normalizeExecutionStatus('Ongoing')).toBe('Ongoing') })
  test('Executed until current month', () => {
    expect(normalizeExecutionStatus('Executed until current month')).toBe('Executed until current month')
  })
})
