import { calculateFinance } from '../../lib/analytics/finance'
import type { WorkOrderRecord } from '../../lib/data/types'

function makeWO(overrides: Partial<WorkOrderRecord> = {}): WorkOrderRecord {
  return {
    id: 'test-wo',
    dealName: 'Test WO',
    customerCode: 'CUST001',
    serialNumber: 'SDPL-001',
    natureOfWork: 'One time Project',
    executionStatus: 'Completed',
    dataDeliveryDate: '2025-09-27',
    poLoiDate: '2025-05-16',
    documentType: 'Purchase Order',
    probableStartDate: '2025-05-01',
    probableEndDate: '2025-06-01',
    bdKamPersonnel: 'OWNER_001',
    sector: 'Mining',
    typeOfWork: 'Topography Survey: RGB',
    skylarksoftwarePlatform: 'NONE',
    amountExclGST: 100_000,
    amountInclGST: 118_000,
    billedExclGST: 80_000,
    billedInclGST: 94_400,
    collectedInclGST: 50_000,
    toBeBilledExclGST: 20_000,
    toBeBilledInclGST: 23_600,
    amountReceivable: 44_400,
    arPriority: false,
    invoiceStatus: 'Partially Billed',
    expectedBillingMonth: null,
    actualBillingMonth: 'July',
    actualCollectionMonth: null,
    woStatus: 'Open',
    collectionStatus: 'Partial',
    collectionDate: null,
    billingStatus: 'Partially Billed',
    _missingAmount: false,
    _missingBilledValue: false,
    _missingCollected: false,
    _missingReceivable: false,
    ...overrides,
  }
}

describe('calculateFinance', () => {
  test('sums billed values correctly', () => {
    const wos = [
      makeWO({ billedExclGST: 80_000 }),
      makeWO({ billedExclGST: 120_000 }),
    ]
    const result = calculateFinance(wos)
    expect(result.totalBilledExclGST).toBe(200_000)
  })

  test('sums collected amounts correctly', () => {
    const wos = [
      makeWO({ collectedInclGST: 50_000 }),
      makeWO({ collectedInclGST: 75_000 }),
    ]
    const result = calculateFinance(wos)
    expect(result.totalCollected).toBe(125_000)
  })

  test('sums receivables correctly', () => {
    const wos = [
      makeWO({ amountReceivable: 44_400 }),
      makeWO({ amountReceivable: 30_000 }),
    ]
    const result = calculateFinance(wos)
    expect(result.totalReceivable).toBe(74_400)
  })

  test('excludes null values from sums', () => {
    const wos = [
      makeWO({ billedExclGST: 100_000 }),
      makeWO({ billedExclGST: null, _missingBilledValue: true }),
    ]
    const result = calculateFinance(wos)
    expect(result.totalBilledExclGST).toBe(100_000)
  })

  test('counts priority AR accounts', () => {
    const wos = [
      makeWO({ arPriority: true, amountReceivable: 50_000 }),
      makeWO({ arPriority: false, amountReceivable: 20_000 }),
    ]
    const result = calculateFinance(wos)
    expect(result.priorityReceivableCount).toBe(1)
    expect(result.outstandingPriority).toBe(50_000)
  })

  test('calculates collection rate', () => {
    const wos = [
      makeWO({ billedInclGST: 100_000, collectedInclGST: 60_000 }),
    ]
    const result = calculateFinance(wos)
    expect(result.collectionRate).toBeCloseTo(0.6)
  })

  test('returns null collection rate for zero billing', () => {
    const wos = [makeWO({ billedInclGST: 0, collectedInclGST: 0 })]
    // Note: 0 billed → null collection rate
    const result = calculateFinance(wos)
    expect(result.collectionRate).toBeNull()
  })
})
