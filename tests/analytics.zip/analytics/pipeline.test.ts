import { calculatePipeline, filterDealsByQuarter, filterDealsBySector } from '../../lib/analytics/pipeline'
import type { DealRecord } from '../../lib/data/types'

function makeDeal(overrides: Partial<DealRecord> = {}): DealRecord {
  return {
    id: 'test-deal',
    dealName: 'Test Deal',
    ownerCode: 'OWNER_001',
    clientCode: 'COMP001',
    status: 'Open',
    closeDate: '2026-03-31',
    closureProbabilityLabel: 'High',
    closureProbabilityValue: 0.75,
    dealValue: 1_000_000,
    tentativeCloseDate: null,
    dealStage: 'E. Proposal/Commercials Sent',
    product: null,
    sector: 'Mining',
    createdDate: '2025-12-01',
    _missingValue: false,
    _missingProbability: false,
    _missingCloseDate: false,
    _missingCreatedDate: false,
    ...overrides,
  }
}

describe('calculatePipeline', () => {
  test('counts deals correctly', () => {
    const deals = [
      makeDeal({ status: 'Open' }),
      makeDeal({ status: 'Won' }),
      makeDeal({ status: 'Lost' }),
    ]
    const result = calculatePipeline(deals)
    expect(result.totalDeals).toBe(3)
    expect(result.openDeals).toBe(1)
    expect(result.wonDeals).toBe(1)
    expect(result.lostDeals).toBe(1)
  })

  test('calculates pipeline value from open deals only', () => {
    const deals = [
      makeDeal({ status: 'Open', dealValue: 1_000_000 }),
      makeDeal({ status: 'Won', dealValue: 500_000 }),
    ]
    const result = calculatePipeline(deals)
    expect(result.pipelineValue).toBe(1_000_000)
  })

  test('calculates weighted pipeline correctly', () => {
    const deals = [
      makeDeal({ status: 'Open', dealValue: 1_000_000, closureProbabilityValue: 0.75 }),
      makeDeal({ status: 'Open', dealValue: 2_000_000, closureProbabilityValue: 0.5 }),
    ]
    const result = calculatePipeline(deals)
    // 1M * 0.75 + 2M * 0.5 = 750K + 1M = 1.75M
    expect(result.weightedPipeline).toBeCloseTo(1_750_000)
  })

  test('excludes deals with missing value from pipeline', () => {
    const deals = [
      makeDeal({ status: 'Open', dealValue: 1_000_000 }),
      makeDeal({ status: 'Open', dealValue: null, _missingValue: true }),
    ]
    const result = calculatePipeline(deals)
    expect(result.pipelineValue).toBe(1_000_000)
    expect(result.dealsWithoutValue).toBe(1)
  })

  test('excludes deals with missing probability from weighted pipeline', () => {
    const deals = [
      makeDeal({ status: 'Open', dealValue: 1_000_000, closureProbabilityValue: 0.75 }),
      makeDeal({ status: 'Open', dealValue: 500_000, closureProbabilityValue: null, _missingProbability: true }),
    ]
    const result = calculatePipeline(deals)
    expect(result.weightedPipeline).toBeCloseTo(750_000)
    expect(result.weightedPipelineDealsIncluded).toBe(1)
  })

  test('counts stage distribution', () => {
    const deals = [
      makeDeal({ dealStage: 'E. Proposal/Commercials Sent' }),
      makeDeal({ dealStage: 'E. Proposal/Commercials Sent' }),
      makeDeal({ dealStage: 'F. Negotiations' }),
    ]
    const result = calculatePipeline(deals)
    expect(result.stageDistribution['E. Proposal/Commercials Sent']).toBe(2)
    expect(result.stageDistribution['F. Negotiations']).toBe(1)
  })
})

describe('filterDealsBySector', () => {
  test('filters deals by sector case-insensitively', () => {
    const deals = [
      makeDeal({ sector: 'Mining' }),
      makeDeal({ sector: 'Powerline' }),
      makeDeal({ sector: 'Mining' }),
    ]
    const result = filterDealsBySector(deals, 'mining')
    expect(result).toHaveLength(2)
  })
})

describe('filterDealsByQuarter', () => {
  test('returns all deals when no filter specified', () => {
    const deals = [makeDeal(), makeDeal()]
    expect(filterDealsByQuarter(deals, {})).toHaveLength(2)
  })

  test('filters by year and quarter', () => {
    const deals = [
      makeDeal({ closeDate: '2026-03-15' }),  // Q1 2026
      makeDeal({ closeDate: '2026-07-15' }),  // Q3 2026
      makeDeal({ closeDate: '2025-12-15' }),  // Q4 2025
    ]
    const result = filterDealsByQuarter(deals, { year: 2026, quarter: 1 })
    expect(result).toHaveLength(1)
    expect(result[0].closeDate).toBe('2026-03-15')
  })

  test('excludes deals with no close date', () => {
    const deals = [
      makeDeal({ closeDate: '2026-03-15' }),
      makeDeal({ closeDate: null, _missingCloseDate: true }),
    ]
    const result = filterDealsByQuarter(deals, { year: 2026, quarter: 1 })
    expect(result).toHaveLength(1)
  })
})
