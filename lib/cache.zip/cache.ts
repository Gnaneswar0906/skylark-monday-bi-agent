import type { DealRecord, WorkOrderRecord } from './data/types'
import type { DataAdapter } from './data/adapters'

interface CacheEntry {
  deals: DealRecord[]
  workOrders: WorkOrderRecord[]
  timestamp: number
}

// Module-level cache (persists across requests in the same server process)
let cache: CacheEntry | null = null

function getTTL(): number {
  const ttl = parseInt(process.env.CACHE_TTL_SECONDS ?? '300', 10)
  return isNaN(ttl) ? 300 : ttl
}

export function isCacheValid(): boolean {
  if (!cache) return false
  const ttlMs = getTTL() * 1000
  return Date.now() - cache.timestamp < ttlMs
}

export function getCachedData(): CacheEntry | null {
  if (isCacheValid()) return cache
  return null
}

export function setCachedData(deals: DealRecord[], workOrders: WorkOrderRecord[]): void {
  cache = { deals, workOrders, timestamp: Date.now() }
}

export function invalidateCache(): void {
  cache = null
}

export function getLastRefreshTime(): string | null {
  if (!cache) return null
  return new Date(cache.timestamp).toISOString()
}

/** Fetch data using the adapter, with caching */
export async function getDataWithCache(adapter: DataAdapter): Promise<{
  deals: DealRecord[]
  workOrders: WorkOrderRecord[]
  fromCache: boolean
}> {
  const cached = getCachedData()
  if (cached) {
    return { deals: cached.deals, workOrders: cached.workOrders, fromCache: true }
  }

  const [deals, workOrders] = await Promise.all([
    adapter.getDeals(),
    adapter.getWorkOrders(),
  ])

  setCachedData(deals, workOrders)
  return { deals, workOrders, fromCache: false }
}

/** Get the appropriate data adapter based on environment */
export async function getAdapter(): Promise<DataAdapter> {
  const dataSource = process.env.DATA_SOURCE ?? 'monday'

  if (dataSource === 'fixture') {
    const { FixtureDataAdapter } = await import('./data/fixtureAdapter')
    return new FixtureDataAdapter()
  }

  // Check if Monday credentials are configured
  const hasMonday =
    process.env.MONDAY_API_TOKEN &&
    process.env.MONDAY_DEALS_BOARD_ID &&
    process.env.MONDAY_WORK_ORDERS_BOARD_ID

  if (hasMonday) {
    const { MondayDataAdapter } = await import('./data/mondayAdapter')
    return new MondayDataAdapter()
  }

  // Fall back to fixtures if Monday is not configured
  console.warn('Monday.com credentials not configured — falling back to fixture data.')
  const { FixtureDataAdapter } = await import('./data/fixtureAdapter')
  return new FixtureDataAdapter()
}
