import type { DealRecord, WorkOrderRecord } from '../data/types'
import { calculatePipeline, filterDealsBySector } from './pipeline'
import { calculateFinance, filterWorkOrdersBySector } from './finance'
import { calculateWorkOrders } from './workorders'

export interface SectorSummary {
  sector: string
  deals: {
    total: number
    open: number
    won: number
    lost: number
    pipelineValue: number
    weightedPipeline: number
    stageDistribution: Record<string, number>
  }
  operations: {
    totalWorkOrders: number
    completed: number
    ongoing: number
    notStarted: number
    executionStatusDistribution: Record<string, number>
  }
  finance: {
    totalBilled: number
    totalCollected: number
    totalReceivable: number
  }
}

export interface SectorLeaderboard {
  sectors: SectorSummary[]
  topSectorByPipeline: string | null
  topSectorByRevenue: string | null
}

/** Get all unique sectors from both deals and work orders */
export function getAllSectors(deals: DealRecord[], workOrders: WorkOrderRecord[]): string[] {
  const sectors = new Set<string>()
  for (const d of deals) if (d.sector) sectors.add(d.sector)
  for (const w of workOrders) if (w.sector) sectors.add(w.sector)
  return Array.from(sectors).sort()
}

/** Analyze a single sector across deals and work orders */
export function analyzeSector(
  sector: string,
  deals: DealRecord[],
  workOrders: WorkOrderRecord[]
): SectorSummary {
  const sectorDeals = filterDealsBySector(deals, sector)
  const sectorWOs = filterWorkOrdersBySector(workOrders, sector)

  const pipeline = calculatePipeline(sectorDeals)
  const finance = calculateFinance(sectorWOs)
  const ops = calculateWorkOrders(sectorWOs)

  return {
    sector,
    deals: {
      total: pipeline.totalDeals,
      open: pipeline.openDeals,
      won: pipeline.wonDeals,
      lost: pipeline.lostDeals,
      pipelineValue: pipeline.pipelineValue,
      weightedPipeline: pipeline.weightedPipeline,
      stageDistribution: pipeline.stageDistribution,
    },
    operations: {
      totalWorkOrders: ops.total,
      completed: ops.completed,
      ongoing: ops.ongoing,
      notStarted: ops.notStarted,
      executionStatusDistribution: ops.statusDistribution,
    },
    finance: {
      totalBilled: finance.totalBilledExclGST,
      totalCollected: finance.totalCollected,
      totalReceivable: finance.totalReceivable,
    },
  }
}

/** Build a sector leaderboard across all sectors */
export function buildSectorLeaderboard(
  deals: DealRecord[],
  workOrders: WorkOrderRecord[]
): SectorLeaderboard {
  const sectors = getAllSectors(deals, workOrders)
  const summaries = sectors.map((s) => analyzeSector(s, deals, workOrders))

  // Sort by pipeline value descending
  summaries.sort((a, b) => b.deals.pipelineValue - a.deals.pipelineValue)

  const topSectorByPipeline = summaries.length > 0 ? summaries[0].sector : null
  const topSectorByRevenue =
    summaries.length > 0
      ? [...summaries].sort((a, b) => b.finance.totalBilled - a.finance.totalBilled)[0].sector
      : null

  return { sectors: summaries, topSectorByPipeline, topSectorByRevenue }
}


