import type { WorkOrderRecord } from '../data/types'

export interface FinanceMetrics {
  totalAmountExclGST: number
  totalAmountInclGST: number
  totalBilledExclGST: number
  totalBilledInclGST: number
  totalCollected: number
  totalReceivable: number
  collectionRate: number | null
  billingRate: number | null
  outstandingPriority: number
  collectionsGap: number
  priorityReceivableCount: number
  billingStatusDistribution: Record<string, number>
  collectionStatusDistribution: Record<string, number>
}

export function filterWorkOrdersBySector(
  workOrders: WorkOrderRecord[],
  sector: string
): WorkOrderRecord[] {
  const s = sector.toLowerCase().trim()
  return workOrders.filter((w) => w.sector?.toLowerCase() === s)
}

export function calculateFinance(workOrders: WorkOrderRecord[]): FinanceMetrics {
  let totalAmountExcl = 0
  let totalAmountIncl = 0
  let totalBilledExcl = 0
  let totalBilledIncl = 0
  let totalCollected = 0
  let totalReceivable = 0
  let outstandingPriority = 0
  let priorityReceivableCount = 0

  for (const wo of workOrders) {
    if (wo.amountExclGST !== null) totalAmountExcl += wo.amountExclGST
    if (wo.amountInclGST !== null) totalAmountIncl += wo.amountInclGST
    if (wo.billedExclGST !== null) totalBilledExcl += wo.billedExclGST
    if (wo.billedInclGST !== null) totalBilledIncl += wo.billedInclGST
    if (wo.collectedInclGST !== null) totalCollected += wo.collectedInclGST
    if (wo.amountReceivable !== null) totalReceivable += wo.amountReceivable
    if (wo.arPriority && wo.amountReceivable !== null) {
      outstandingPriority += wo.amountReceivable
      priorityReceivableCount++
    }
  }

  // Collection rate = collected / billed incl GST
  const collectionRate =
    totalBilledIncl > 0 ? Math.min(totalCollected / totalBilledIncl, 1) : null

  // Billing rate = billed excl / total amount excl
  const billingRate = totalAmountExcl > 0 ? Math.min(totalBilledExcl / totalAmountExcl, 1) : null

  const collectionsGap = totalBilledIncl - totalCollected

  // Status distributions
  const billingStatusDistribution: Record<string, number> = {}
  const collectionStatusDistribution: Record<string, number> = {}

  for (const wo of workOrders) {
    const bs = wo.billingStatus ?? 'Unknown'
    billingStatusDistribution[bs] = (billingStatusDistribution[bs] ?? 0) + 1
    const cs = wo.collectionStatus
    collectionStatusDistribution[cs] = (collectionStatusDistribution[cs] ?? 0) + 1
  }

  return {
    totalAmountExclGST: totalAmountExcl,
    totalAmountInclGST: totalAmountIncl,
    totalBilledExclGST: totalBilledExcl,
    totalBilledInclGST: totalBilledIncl,
    totalCollected,
    totalReceivable,
    collectionRate,
    billingRate,
    outstandingPriority,
    collectionsGap,
    priorityReceivableCount,
    billingStatusDistribution,
    collectionStatusDistribution,
  }
}
