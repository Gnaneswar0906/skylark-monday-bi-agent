import type { WorkOrderRecord } from '../data/types'

export interface WorkOrderMetrics {
  total: number
  completed: number
  ongoing: number
  notStarted: number
  onHold: number
  executedUntilCurrentMonth: number
  inProgress: number
  unknown: number
  statusDistribution: Record<string, number>
  completionRate: number | null
  priorityReceivables: number
}

export function calculateWorkOrders(workOrders: WorkOrderRecord[]): WorkOrderMetrics {
  const completed = workOrders.filter((w) => w.executionStatus === 'Completed').length
  const ongoing = workOrders.filter((w) => w.executionStatus === 'Ongoing').length
  const notStarted = workOrders.filter((w) => w.executionStatus === 'Not Started').length
  const onHold = workOrders.filter((w) => w.executionStatus === 'On Hold').length
  const executedUntilCurrentMonth = workOrders.filter(
    (w) => w.executionStatus === 'Executed until current month'
  ).length
  const inProgress = workOrders.filter((w) => w.executionStatus === 'In Progress').length
  const unknown = workOrders.filter((w) => w.executionStatus === 'Unknown').length

  const statusDistribution: Record<string, number> = {}
  for (const wo of workOrders) {
    const s = wo.executionStatus
    statusDistribution[s] = (statusDistribution[s] ?? 0) + 1
  }

  const total = workOrders.length
  const completionRate = total > 0 ? completed / total : null

  const priorityReceivables = workOrders.filter((w) => w.arPriority).length

  return {
    total,
    completed,
    ongoing,
    notStarted,
    onHold,
    executedUntilCurrentMonth,
    inProgress,
    unknown,
    statusDistribution,
    completionRate,
    priorityReceivables,
  }
}
