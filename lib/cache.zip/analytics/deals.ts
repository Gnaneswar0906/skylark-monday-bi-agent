import type { DealRecord } from '../data/types'

export interface DealAnalysis {
  biggestDeals: DealRecord[]
  atRiskDeals: DealRecord[]
  staleDeals: DealRecord[]
}

/** Get the N biggest deals by deal value */
export function getBiggestDeals(deals: DealRecord[], n = 10): DealRecord[] {
  return [...deals]
    .filter((d) => d.dealValue !== null && d.status === 'Open')
    .sort((a, b) => (b.dealValue ?? 0) - (a.dealValue ?? 0))
    .slice(0, n)
}

/** At-risk deals: Low probability and high deal value, or very old open deals */
export function getAtRiskDeals(deals: DealRecord[]): DealRecord[] {
  const now = new Date()
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

  return deals.filter((d) => {
    if (d.status !== 'Open') return false
    // Low probability with value
    if (d.closureProbabilityLabel === 'Low' && d.dealValue !== null) return true
    // High value with no probability assigned
    if (d.closureProbabilityValue === null && d.dealValue !== null && d.dealValue > 1_000_000) return true
    // Overdue (close date has passed)
    if (d.closeDate) {
      const closeDate = new Date(d.closeDate)
      if (closeDate < now) return true
    }
    return false
  })
}

/** Stale deals: No close date, no probability, open for long time */
export function getStaleDeals(deals: DealRecord[]): DealRecord[] {
  return deals.filter(
    (d) =>
      d.status === 'Open' &&
      d.closureProbabilityValue === null &&
      d.dealValue === null
  )
}
