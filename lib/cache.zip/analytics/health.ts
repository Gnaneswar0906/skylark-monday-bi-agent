import type { DealRecord, WorkOrderRecord } from '../data/types'
import { calculatePipeline } from './pipeline'
import { calculateFinance } from './finance'
import { calculateWorkOrders } from './workorders'
import { buildSectorLeaderboard } from './sectors'

export interface BusinessHealthMetrics {
  salesHealth: 'Strong' | 'Moderate' | 'Weak'
  operationalHealth: 'Strong' | 'Moderate' | 'Weak'
  financialHealth: 'Strong' | 'Moderate' | 'Weak'
  overallHealth: 'Strong' | 'Moderate' | 'Weak'
  pipeline: ReturnType<typeof calculatePipeline>
  finance: ReturnType<typeof calculateFinance>
  operations: ReturnType<typeof calculateWorkOrders>
  topSectors: string[]
  risks: string[]
  recommendations: string[]
}

function healthLevel(score: number): 'Strong' | 'Moderate' | 'Weak' {
  if (score >= 0.7) return 'Strong'
  if (score >= 0.4) return 'Moderate'
  return 'Weak'
}

export function calculateBusinessHealth(
  deals: DealRecord[],
  workOrders: WorkOrderRecord[]
): BusinessHealthMetrics {
  const pipeline = calculatePipeline(deals)
  const finance = calculateFinance(workOrders)
  const operations = calculateWorkOrders(workOrders)
  const sectorLeaderboard = buildSectorLeaderboard(deals, workOrders)

  // Sales health score
  const openRatio = pipeline.totalDeals > 0 ? pipeline.openDeals / pipeline.totalDeals : 0
  const probCoverage =
    pipeline.openDeals > 0 ? pipeline.dealsWithProbability / pipeline.openDeals : 0
  const salesScore = (openRatio * 0.4 + probCoverage * 0.6)
  const salesHealth = healthLevel(salesScore)

  // Operational health score
  const completionRate = operations.completionRate ?? 0
  const operationalHealth = healthLevel(completionRate)

  // Financial health score
  const collectionRate = finance.collectionRate ?? 0
  const billingRate = finance.billingRate ?? 0
  const financialScore = (collectionRate * 0.6 + billingRate * 0.4)
  const financialHealth = healthLevel(financialScore)

  // Overall
  const scores = {
    Strong: 3,
    Moderate: 2,
    Weak: 1,
  }
  const avg = (scores[salesHealth] + scores[operationalHealth] + scores[financialHealth]) / 3
  const overallHealth = avg >= 2.5 ? 'Strong' : avg >= 1.5 ? 'Moderate' : 'Weak'

  // Risks
  const risks: string[] = []
  if (pipeline.dealsWithoutProbability > 5)
    risks.push(`${pipeline.dealsWithoutProbability} deals are missing closure probability, limiting pipeline confidence.`)
  if (pipeline.dealsWithoutValue > 5)
    risks.push(`${pipeline.dealsWithoutValue} open deals have no deal value — pipeline may be underreported.`)
  if (finance.collectionRate !== null && finance.collectionRate < 0.5)
    risks.push(`Collection rate is below 50% — ${(finance.collectionsGap / 1_00_000).toFixed(1)}L in billed amount is uncollected.`)
  if (finance.priorityReceivableCount > 0)
    risks.push(`${finance.priorityReceivableCount} work orders have priority AR status — requires immediate follow-up.`)
  if (operations.notStarted > 5)
    risks.push(`${operations.notStarted} work orders have not started — potential delivery risk.`)

  // Recommendations
  const recommendations: string[] = [
    'Review deals with missing probability assignments to improve pipeline accuracy.',
    'Follow up on priority receivable accounts to accelerate collections.',
    'Prioritize high-probability deals close to their target close date.',
  ]
  if (operations.notStarted > 0)
    recommendations.push('Initiate planning for work orders not yet started.')

  const topSectors = sectorLeaderboard.sectors
    .slice(0, 3)
    .map((s) => s.sector)

  return {
    salesHealth,
    operationalHealth,
    financialHealth,
    overallHealth,
    pipeline,
    finance,
    operations,
    topSectors,
    risks,
    recommendations,
  }
}
