import type { DealRecord, WorkOrderRecord } from '../data/types'
import { calculatePipeline } from './pipeline'
import { calculateFinance } from './finance'
import { calculateWorkOrders } from './workorders'
import { buildSectorLeaderboard } from './sectors'

export interface LeadershipUpdate {
  sales: {
    totalDeals: number
    openDeals: number
    wonDeals: number
    pipelineValue: number
    weightedPipeline: number
    topSector: string | null
  }
  operations: {
    totalWorkOrders: number
    completed: number
    ongoing: number
    notStarted: number
    completionRate: number | null
  }
  financial: {
    totalBilled: number
    totalCollected: number
    totalReceivable: number
    collectionRate: number | null
    priorityAccountsCount: number
  }
  keyRisks: string[]
  leadershipAttention: string[]
  generatedAt: string
}

export function generateLeadershipUpdate(
  deals: DealRecord[],
  workOrders: WorkOrderRecord[]
): LeadershipUpdate {
  const pipeline = calculatePipeline(deals)
  const finance = calculateFinance(workOrders)
  const ops = calculateWorkOrders(workOrders)
  const sectorBoard = buildSectorLeaderboard(deals, workOrders)

  const keyRisks: string[] = []
  const attention: string[] = []

  if (pipeline.dealsWithoutProbability > 0)
    keyRisks.push(`${pipeline.dealsWithoutProbability} deals missing closure probability.`)
  if (finance.collectionRate !== null && finance.collectionRate < 0.6)
    keyRisks.push(`Collection rate is ${(finance.collectionRate * 100).toFixed(0)}% — below 60% target.`)
  if (finance.totalReceivable > 50_00_000)
    keyRisks.push(`₹${(finance.totalReceivable / 1_00_000).toFixed(1)}L in outstanding receivables.`)
  if (ops.notStarted > 0)
    keyRisks.push(`${ops.notStarted} work orders have not been started.`)
  if (finance.priorityReceivableCount > 0)
    keyRisks.push(`${finance.priorityReceivableCount} priority AR accounts require follow-up.`)

  attention.push('Prioritize high-value opportunities in the pipeline.')
  if (ops.notStarted > 0) attention.push('Expedite onboarding of work orders not yet started.')
  if (finance.priorityReceivableCount > 0) attention.push('Personally follow up on priority receivable accounts.')
  attention.push('Review deals that have passed their tentative close date.')

  return {
    sales: {
      totalDeals: pipeline.totalDeals,
      openDeals: pipeline.openDeals,
      wonDeals: pipeline.wonDeals,
      pipelineValue: pipeline.pipelineValue,
      weightedPipeline: pipeline.weightedPipeline,
      topSector: sectorBoard.topSectorByPipeline,
    },
    operations: {
      totalWorkOrders: ops.total,
      completed: ops.completed,
      ongoing: ops.ongoing,
      notStarted: ops.notStarted,
      completionRate: ops.completionRate,
    },
    financial: {
      totalBilled: finance.totalBilledExclGST,
      totalCollected: finance.totalCollected,
      totalReceivable: finance.totalReceivable,
      collectionRate: finance.collectionRate,
      priorityAccountsCount: finance.priorityReceivableCount,
    },
    keyRisks,
    leadershipAttention: attention,
    generatedAt: new Date().toISOString(),
  }
}
