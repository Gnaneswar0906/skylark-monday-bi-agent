import { getQuarter, getYear, parseISO, isValid } from 'date-fns'
import type { DealRecord } from '../data/types'

export interface PipelineMetrics {
  totalDeals: number
  openDeals: number
  wonDeals: number
  lostDeals: number
  onHoldDeals: number
  pipelineValue: number
  weightedPipeline: number
  averageDealValue: number | null
  dealsWithValue: number
  dealsWithoutValue: number
  dealsWithProbability: number
  dealsWithoutProbability: number
  weightedPipelineDealsIncluded: number
  stageDistribution: Record<string, number>
}

export interface QuarterFilter {
  year?: number
  quarter?: number // 1-4
}

/** Filter deals by quarter based on closeDate or tentativeCloseDate */
export function filterDealsByQuarter(
  deals: DealRecord[],
  filter: QuarterFilter
): DealRecord[] {
  if (!filter.year && !filter.quarter) return deals
  return deals.filter((d) => {
    const dateStr = d.closeDate ?? d.tentativeCloseDate
    if (!dateStr) return false
    try {
      const date = parseISO(dateStr)
      if (!isValid(date)) return false
      if (filter.year && getYear(date) !== filter.year) return false
      if (filter.quarter && getQuarter(date) !== filter.quarter) return false
      return true
    } catch {
      return false
    }
  })
}

/** Filter deals by sector (case-insensitive) */
export function filterDealsBySector(deals: DealRecord[], sector: string): DealRecord[] {
  const s = sector.toLowerCase().trim()
  return deals.filter((d) => d.sector?.toLowerCase() === s)
}

/** Calculate all pipeline metrics for a set of deals */
export function calculatePipeline(deals: DealRecord[]): PipelineMetrics {
  const openDeals = deals.filter((d) => d.status === 'Open')
  const wonDeals = deals.filter((d) => d.status === 'Won')
  const lostDeals = deals.filter((d) => d.status === 'Lost')
  const onHoldDeals = deals.filter((d) => d.status === 'On Hold')

  // Pipeline value = sum of deal values for open deals
  const dealsWithValue = openDeals.filter((d) => d.dealValue !== null)
  const pipelineValue = dealsWithValue.reduce((sum, d) => sum + (d.dealValue ?? 0), 0)

  // Weighted pipeline = dealValue × closureProbabilityValue
  const weightedPipelineDeals = openDeals.filter(
    (d) => d.dealValue !== null && d.closureProbabilityValue !== null
  )
  const weightedPipeline = weightedPipelineDeals.reduce(
    (sum, d) => sum + (d.dealValue ?? 0) * (d.closureProbabilityValue ?? 0),
    0
  )

  const allDealsWithValue = deals.filter((d) => d.dealValue !== null)
  const avgDealValue =
    allDealsWithValue.length > 0
      ? allDealsWithValue.reduce((sum, d) => sum + (d.dealValue ?? 0), 0) / allDealsWithValue.length
      : null

  // Stage distribution
  const stageDistribution: Record<string, number> = {}
  for (const deal of deals) {
    const stage = deal.dealStage
    stageDistribution[stage] = (stageDistribution[stage] ?? 0) + 1
  }

  return {
    totalDeals: deals.length,
    openDeals: openDeals.length,
    wonDeals: wonDeals.length,
    lostDeals: lostDeals.length,
    onHoldDeals: onHoldDeals.length,
    pipelineValue,
    weightedPipeline,
    averageDealValue: avgDealValue,
    dealsWithValue: dealsWithValue.length,
    dealsWithoutValue: openDeals.length - dealsWithValue.length,
    dealsWithProbability: openDeals.filter((d) => d.closureProbabilityValue !== null).length,
    dealsWithoutProbability: openDeals.filter((d) => d.closureProbabilityValue === null).length,
    weightedPipelineDealsIncluded: weightedPipelineDeals.length,
    stageDistribution,
  }
}
