import { mondayQuery } from './client'
import { paginateAllItems } from './pagination'

export interface MondayColumn {
  id: string
  title: string
  type: string
}

export interface MondayColumnValue {
  id: string
  text: string
  value: string | null
  type: string
  column: { title: string }
}

export interface MondayItem {
  id: string
  name: string
  column_values: MondayColumnValue[]
}

interface BoardMetaResponse {
  boards: {
    id: string
    name: string
    columns: MondayColumn[]
  }[]
}

/** Fetch column metadata for a board */
export async function getBoardColumns(boardId: string): Promise<MondayColumn[]> {
  const QUERY = `
    query GetBoardColumns($boardId: ID!) {
      boards(ids: [$boardId]) {
        id
        name
        columns {
          id
          title
          type
        }
      }
    }
  `
  const data = await mondayQuery<BoardMetaResponse>(QUERY, { boardId })
  if (!data.boards || data.boards.length === 0) {
    throw new Error(`Board ${boardId} not found in Monday.com.`)
  }
  return data.boards[0].columns
}

/** Fetch all items from a board, handling pagination */
export async function fetchBoardItems(
  boardId: string
): Promise<{ columns: MondayColumn[]; items: MondayItem[] }> {
  const columns = await getBoardColumns(boardId)
  const items = await paginateAllItems(boardId)
  return { columns, items }
}
