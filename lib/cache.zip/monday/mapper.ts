import type { MondayColumn, MondayItem, MondayColumnValue } from './boards'
import type { DealRecord, WorkOrderRecord } from '../data/types'
import {
  normalizeText,
  normalizeSector,
  normalizeDate,
  normalizeNumeric,
  normalizeProbability,
  normalizeProbabilityLabel,
  normalizeDealStatus,
  normalizeDealStage,
  normalizeExecutionStatus,
  normalizeWOStatus,
  normalizeInvoiceStatus,
  normalizeCollectionStatus,
  normalizeARPriority,
} from '../data/normalize'

/** Build a lookup map: normalized column title → column value */
function buildColumnMap(
  columnValues: MondayColumnValue[],
  _columns: MondayColumn[]
): Map<string, string> {
  const map = new Map<string, string>()
  for (const cv of columnValues) {
    const title = (cv.column?.title ?? cv.id).toLowerCase().trim()
    const text = cv.text?.trim() ?? ''
    if (text) map.set(title, text)
  }
  return map
}

function get(map: Map<string, string>, ...keys: string[]): string | null {
  for (const k of keys) {
    const val = map.get(k.toLowerCase())
    if (val && val !== '' && val !== '-') return val
  }
  return null
}

export function mapDealRecord(
  item: MondayItem,
  columns: MondayColumn[],
  index: number
): DealRecord {
  const colMap = buildColumnMap(item.column_values, columns)
  const dealValueRaw = get(colMap, 'masked deal value', 'deal value', 'deal_value')
  const probRaw = get(colMap, 'closure probability', 'probability')
  const closeDateRaw = get(colMap, 'close date (a)', 'close date', 'close_date')
  const createdRaw = get(colMap, 'created date', 'created_date')

  const dealValue = normalizeNumeric(dealValueRaw)
  const probValue = normalizeProbability(probRaw)
  const closeDate = normalizeDate(closeDateRaw)
  const createdDate = normalizeDate(createdRaw)

  return {
    id: item.id ?? `deal-${index}`,
    dealName: normalizeText(item.name),
    ownerCode: get(colMap, 'owner code', 'owner_code'),
    clientCode: get(colMap, 'client code', 'client_code'),
    status: normalizeDealStatus(get(colMap, 'deal status', 'status')),
    closeDate,
    closureProbabilityLabel: normalizeProbabilityLabel(probRaw),
    closureProbabilityValue: probValue,
    dealValue,
    tentativeCloseDate: normalizeDate(get(colMap, 'tentative close date')),
    dealStage: normalizeDealStage(get(colMap, 'deal stage', 'stage')),
    product: normalizeText(get(colMap, 'product deal', 'product')),
    sector: normalizeSector(get(colMap, 'sector/service', 'sector')),
    createdDate,
    _missingValue: dealValue === null,
    _missingProbability: probValue === null,
    _missingCloseDate: closeDate === null,
    _missingCreatedDate: createdDate === null,
  }
}

export function mapWorkOrderRecord(
  item: MondayItem,
  columns: MondayColumn[],
  index: number
): WorkOrderRecord {
  const colMap = buildColumnMap(item.column_values, columns)

  const amountExclGST = normalizeNumeric(get(colMap, 'amount in rupees (excl of gst) (masked)', 'amount excl gst', 'amount'))
  const amountInclGST = normalizeNumeric(get(colMap, 'amount in rupees (incl of gst) (masked)', 'amount incl gst'))
  const billedExcl = normalizeNumeric(get(colMap, 'billed value in rupees (excl of gst.) (masked)', 'billed excl gst'))
  const billedIncl = normalizeNumeric(get(colMap, 'billed value in rupees (incl of gst.) (masked)', 'billed incl gst'))
  const collected = normalizeNumeric(get(colMap, 'collected amount in rupees (incl of gst.) (masked)', 'collected'))
  const toBeBilledExcl = normalizeNumeric(get(colMap, 'amount to be billed in rs. (exl. of gst) (masked)'))
  const toBeBilledIncl = normalizeNumeric(get(colMap, 'amount to be billed in rs. (incl. of gst) (masked)'))
  const receivable = normalizeNumeric(get(colMap, 'amount receivable (masked)', 'amount receivable'))

  return {
    id: item.id ?? `wo-${index}`,
    dealName: normalizeText(item.name),
    customerCode: get(colMap, 'customer name code', 'customer code'),
    serialNumber: get(colMap, 'serial #', 'serial number'),
    natureOfWork: normalizeText(get(colMap, 'nature of work')),
    executionStatus: normalizeExecutionStatus(get(colMap, 'execution status')),
    dataDeliveryDate: normalizeDate(get(colMap, 'data delivery date')),
    poLoiDate: normalizeDate(get(colMap, 'date of po/loi', 'po date')),
    documentType: get(colMap, 'document type'),
    probableStartDate: normalizeDate(get(colMap, 'probable start date')),
    probableEndDate: normalizeDate(get(colMap, 'probable end date')),
    bdKamPersonnel: get(colMap, 'bd/kam personnel code', 'bd/kam'),
    sector: normalizeSector(get(colMap, 'sector')),
    typeOfWork: normalizeText(get(colMap, 'type of work')),
    skylarksoftwarePlatform: get(colMap, 'is any skylark software platform part of the client deliverables in this deal?'),
    amountExclGST,
    amountInclGST,
    billedExclGST: billedExcl,
    billedInclGST: billedIncl,
    collectedInclGST: collected,
    toBeBilledExclGST: toBeBilledExcl,
    toBeBilledInclGST: toBeBilledIncl,
    amountReceivable: receivable,
    arPriority: normalizeARPriority(get(colMap, 'ar priority account', 'ar priority')),
    invoiceStatus: normalizeInvoiceStatus(get(colMap, 'invoice status')),
    expectedBillingMonth: get(colMap, 'expected billing month'),
    actualBillingMonth: get(colMap, 'actual billing month'),
    actualCollectionMonth: get(colMap, 'actual collection month'),
    woStatus: normalizeWOStatus(get(colMap, 'wo status (billed)', 'wo status')),
    collectionStatus: normalizeCollectionStatus(get(colMap, 'collection status')),
    collectionDate: normalizeDate(get(colMap, 'collection date')),
    billingStatus: (get(colMap, 'billing status') ?? 'Unknown') as WorkOrderRecord['billingStatus'],
    _missingAmount: amountExclGST === null,
    _missingBilledValue: billedExcl === null,
    _missingCollected: collected === null,
    _missingReceivable: receivable === null,
  }
}
