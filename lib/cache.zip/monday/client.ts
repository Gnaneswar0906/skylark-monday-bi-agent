const MONDAY_API_URL = 'https://api.monday.com/v2'

export interface MondayGraphQLResponse<T> {
  data: T
  errors?: { message: string }[]
}

export async function mondayQuery<T>(
  query: string,
  variables?: Record<string, unknown>
): Promise<T> {
  const token = process.env.MONDAY_API_TOKEN
  if (!token) {
    throw new Error('MONDAY_API_TOKEN is not configured.')
  }

  const response = await fetch(MONDAY_API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: token,
      'API-Version': '2024-01',
    },
    body: JSON.stringify({ query, variables }),
    // Server-side only — never expose token to browser
  })

  if (!response.ok) {
    throw new Error(`Monday.com API request failed: ${response.status} ${response.statusText}`)
  }

  const json: MondayGraphQLResponse<T> = await response.json()

  if (json.errors && json.errors.length > 0) {
    throw new Error(`Monday.com GraphQL error: ${json.errors.map((e) => e.message).join(', ')}`)
  }

  return json.data
}

/** Test connectivity to the Monday.com API */
export async function testConnection(): Promise<{ ok: boolean; error?: string }> {
  try {
    await mondayQuery<{ me: { name: string } }>(`{ me { name } }`)
    return { ok: true }
  } catch (err) {
    return { ok: false, error: (err as Error).message }
  }
}
