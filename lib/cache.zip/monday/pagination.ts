import { mondayQuery } from './client'
import type { MondayItem } from './boards'

interface ItemsPage {
  boards: {
    items_page: {
      cursor: string | null
      items: MondayItem[]
    }
  }[]
}

interface NextItemsPage {
  next_items_page: {
    cursor: string | null
    items: MondayItem[]
  }
}

const PAGE_SIZE = 200

const ITEMS_QUERY = `
  query GetItems($boardId: ID!, $limit: Int!) {
    boards(ids: [$boardId]) {
      items_page(limit: $limit) {
        cursor
        items {
          id
          name
          column_values {
            id
            text
            value
            type
            column { title }
          }
        }
      }
    }
  }
`

const NEXT_ITEMS_QUERY = `
  query GetNextItems($cursor: String!, $limit: Int!) {
    next_items_page(cursor: $cursor, limit: $limit) {
      cursor
      items {
        id
        name
        column_values {
          id
          text
          value
          type
          column { title }
        }
      }
    }
  }
`

/** Paginate through all items in a board using cursor-based pagination */
export async function paginateAllItems(boardId: string): Promise<MondayItem[]> {
  const allItems: MondayItem[] = []

  // First page
  const firstPage = await mondayQuery<ItemsPage>(ITEMS_QUERY, {
    boardId,
    limit: PAGE_SIZE,
  })

  const boardData = firstPage.boards?.[0]?.items_page
  if (!boardData) return allItems

  allItems.push(...boardData.items)
  let cursor = boardData.cursor

  // Subsequent pages
  while (cursor) {
    const nextPage = await mondayQuery<NextItemsPage>(NEXT_ITEMS_QUERY, {
      cursor,
      limit: PAGE_SIZE,
    })
    allItems.push(...nextPage.next_items_page.items)
    cursor = nextPage.next_items_page.cursor
  }

  return allItems
}
