import { parse } from 'csv-parse/sync'
import { readFileSync } from 'fs'
import { join } from 'path'
import type { DataAdapter } from './adapters'
import type { DealRecord, WorkOrderRecord } from './types'
import {
  normalizeText,
  normalizeSector,
  normalizeDate,
  normalizeNumeric,
  normalizeProbability,
  normalizeProbabilityLabel,
  normalizeDealStatus,
  normalizeDealStage,
  normalizeExecutionStatus,
  normalizeWOStatus,
  normalizeInvoiceStatus,
  normalizeCollectionStatus,
  normalizeARPriority,
} from './normalize'

function csvRow(row: Record<string, string>, ...keys: string[]): string | null {
  for (const k of keys) {
    const val = row[k]?.trim()
    if (val && val !== '' && val !== '-') return val
  }
  return null
}

export class FixtureDataAdapter implements DataAdapter {
  private dealsPath: string
  private workOrdersPath: string

  constructor() {
    this.dealsPath = join(process.cwd(), 'data', 'Deal funnel Data.xlsx - Deal tracker.csv')
    this.workOrdersPath = join(process.cwd(), 'data', 'Work_Order_Tracker Data.xlsx - work order tracker.csv')
  }

  async getDeals(): Promise<DealRecord[]> {
    const raw = readFileSync(this.dealsPath, 'utf-8')
    const rows: Record<string, string>[] = parse(raw, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
      relax_column_count: true,
    })

    return rows.map((row, i): DealRecord => {
      const dealValueRaw = csvRow(row, 'Masked Deal value', 'Deal Value', 'deal_value')
      const probRaw = csvRow(row, 'Closure Probability', 'closure_probability')
      const closeDateRaw = csvRow(row, 'Close Date (A)', 'Close Date', 'close_date')
      const createdRaw = csvRow(row, 'Created Date', 'created_date')

      const dealValue = normalizeNumeric(dealValueRaw)
      const probLabel = normalizeProbabilityLabel(probRaw)
      const probValue = normalizeProbability(probRaw)
      const closeDate = normalizeDate(closeDateRaw)
      const createdDate = normalizeDate(createdRaw)

      return {
        id: `deal-${i}`,
        dealName: normalizeText(csvRow(row, 'Deal Name', 'deal_name')),
        ownerCode: csvRow(row, 'Owner code', 'Owner Code', 'owner_code'),
        clientCode: csvRow(row, 'Client Code', 'client_code'),
        status: normalizeDealStatus(csvRow(row, 'Deal Status', 'deal_status')),
        closeDate,
        closureProbabilityLabel: probLabel,
        closureProbabilityValue: probValue,
        dealValue,
        tentativeCloseDate: normalizeDate(csvRow(row, 'Tentative Close Date', 'tentative_close_date')),
        dealStage: normalizeDealStage(csvRow(row, 'Deal Stage', 'deal_stage')),
        product: normalizeText(csvRow(row, 'Product deal', 'Product', 'product')),
        sector: normalizeSector(csvRow(row, 'Sector/service', 'Sector', 'sector')),
        createdDate,
        _missingValue: dealValue === null,
        _missingProbability: probValue === null,
        _missingCloseDate: closeDate === null,
        _missingCreatedDate: createdDate === null,
      }
    })
  }

  async getWorkOrders(): Promise<WorkOrderRecord[]> {
    const raw = readFileSync(this.workOrdersPath, 'utf-8')
    // Work orders CSV has a blank first row — skip it
    const lines = raw.split('\n')
    const csvContent = lines.slice(1).join('\n')

    const rows: Record<string, string>[] = parse(csvContent, {
      columns: true,
      skip_empty_lines: true,
      trim: true,
      relax_column_count: true,
    })

    return rows.map((row, i): WorkOrderRecord => {
      const amountExclGST = normalizeNumeric(csvRow(row,
        'Amount in Rupees (Excl of GST) (Masked)',
        'Amount in Rupees (Excl of GST) (masked)',
      ))
      const amountInclGST = normalizeNumeric(csvRow(row,
        'Amount in Rupees (Incl of GST) (Masked)',
        'Amount in Rupees (Incl of GST) (masked)',
      ))
      const billedExcl = normalizeNumeric(csvRow(row,
        'Billed Value in Rupees (Excl of GST.) (Masked)',
      ))
      const billedIncl = normalizeNumeric(csvRow(row,
        'Billed Value in Rupees (Incl of GST.) (Masked)',
      ))
      const collected = normalizeNumeric(csvRow(row,
        'Collected Amount in Rupees (Incl of GST.) (Masked)',
      ))
      const toBeBilledExcl = normalizeNumeric(csvRow(row,
        'Amount to be billed in Rs. (Exl. of GST) (Masked)',
      ))
      const toBeBilledIncl = normalizeNumeric(csvRow(row,
        'Amount to be billed in Rs. (Incl. of GST) (Masked)',
      ))
      const receivable = normalizeNumeric(csvRow(row, 'Amount Receivable (Masked)', 'Amount Receivable'))

      return {
        id: `wo-${i}`,
        dealName: normalizeText(csvRow(row, 'Deal name masked', 'Deal Name')),
        customerCode: csvRow(row, 'Customer Name Code', 'Customer Code'),
        serialNumber: csvRow(row, 'Serial #', 'Serial Number'),
        natureOfWork: normalizeText(csvRow(row, 'Nature of Work')),
        executionStatus: normalizeExecutionStatus(csvRow(row, 'Execution Status')),
        dataDeliveryDate: normalizeDate(csvRow(row, 'Data Delivery Date')),
        poLoiDate: normalizeDate(csvRow(row, 'Date of PO/LOI')),
        documentType: csvRow(row, 'Document Type'),
        probableStartDate: normalizeDate(csvRow(row, 'Probable Start Date')),
        probableEndDate: normalizeDate(csvRow(row, 'Probable End Date')),
        bdKamPersonnel: csvRow(row, 'BD/KAM Personnel code', 'BD/KAM Personnel'),
        sector: normalizeSector(csvRow(row, 'Sector')),
        typeOfWork: normalizeText(csvRow(row, 'Type of Work')),
        skylarksoftwarePlatform: csvRow(row, 'Is any Skylark software platform part of the client deliverables in this deal?'),
        amountExclGST,
        amountInclGST,
        billedExclGST: billedExcl,
        billedInclGST: billedIncl,
        collectedInclGST: collected,
        toBeBilledExclGST: toBeBilledExcl,
        toBeBilledInclGST: toBeBilledIncl,
        amountReceivable: receivable,
        arPriority: normalizeARPriority(csvRow(row, 'AR Priority account', 'AR Priority')),
        invoiceStatus: normalizeInvoiceStatus(csvRow(row, 'Invoice Status')),
        expectedBillingMonth: csvRow(row, 'Expected Billing Month'),
        actualBillingMonth: csvRow(row, 'Actual Billing Month'),
        actualCollectionMonth: csvRow(row, 'Actual Collection Month'),
        woStatus: normalizeWOStatus(csvRow(row, 'WO Status (billed)', 'WO Status')),
        collectionStatus: normalizeCollectionStatus(csvRow(row, 'Collection status', 'Collection Status')),
        collectionDate: normalizeDate(csvRow(row, 'Collection Date')),
        billingStatus: (csvRow(row, 'Billing Status') ?? 'Unknown') as WorkOrderRecord['billingStatus'],
        _missingAmount: amountExclGST === null,
        _missingBilledValue: billedExcl === null,
        _missingCollected: collected === null,
        _missingReceivable: receivable === null,
      }
    })
  }
}
