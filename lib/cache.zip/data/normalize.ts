import { parse, isValid, parseISO } from 'date-fns'
import type {
  DealStatus,
  DealStage,
  ClosureProbability,
  ProbabilityValue,
  ExecutionStatus,
  WOStatus,
  InvoiceStatus,
  CollectionStatus,
} from './types'

// ─── Text ────────────────────────────────────────────────────────────────────

/** Trim + title-case normalization */
export function normalizeText(raw: string | null | undefined): string | null {
  if (raw === null || raw === undefined) return null
  const trimmed = raw.trim()
  if (trimmed === '' || trimmed === '-' || trimmed.toLowerCase() === 'n/a') return null
  return trimmed
    .toLowerCase()
    .replace(/\b\w/g, (c) => c.toUpperCase())
}

/** Normalize sector label */
export function normalizeSector(raw: string | null | undefined): string | null {
  const s = normalizeText(raw)
  if (!s) return null
  // Map common variants
  const MAP: Record<string, string> = {
    'Renewables': 'Renewables',
    'Solar': 'Renewables',
    'Mining': 'Mining',
    'Powerline': 'Powerline',
    'Power Line': 'Powerline',
    'Dsp': 'DSP',
    'Railways': 'Railways',
    'Tender': 'Tender',
    'Utilities': 'Utilities',
    'Energy': 'Energy',
    'Agriculture': 'Agriculture',
    'Oil & Gas': 'Oil & Gas',
    'Oil And Gas': 'Oil & Gas',
  }
  return MAP[s] ?? s
}

// ─── Dates ───────────────────────────────────────────────────────────────────

const DATE_FORMATS = [
  'yyyy-MM-dd',
  'dd-MM-yyyy',
  'MM/dd/yyyy',
  'dd/MM/yyyy',
  'dd MMM yyyy',
  'MMM dd, yyyy',
  'yyyy/MM/dd',
]

/** Format a Date object to YYYY-MM-DD using local date parts */
function toLocalDateString(d: Date): string {
  const year = d.getFullYear()
  const month = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

/** Parse a date string into an ISO date string, or null if invalid */
export function normalizeDate(raw: string | null | undefined): string | null {
  if (!raw) return null
  const trimmed = raw.trim()
  if (!trimmed || trimmed === '-' || trimmed.toLowerCase() === 'n/a') return null

  // Try ISO first (parseISO returns UTC midnight — extract date parts directly)
  const iso = parseISO(trimmed)
  if (isValid(iso)) {
    // For pure date strings like "2025-12-26", parseISO gives UTC midnight
    // Use the string parts directly to avoid timezone shift
    const match = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})/)
    if (match) return `${match[1]}-${match[2]}-${match[3]}`
    return toLocalDateString(iso)
  }

  // Try multiple formats
  for (const fmt of DATE_FORMATS) {
    try {
      const d = parse(trimmed, fmt, new Date())
      if (isValid(d)) return toLocalDateString(d)
    } catch {
      // continue
    }
  }

  return null
}


// ─── Numerics ─────────────────────────────────────────────────────────────────

/** Parse a numeric string, stripping currency symbols and commas */
export function normalizeNumeric(raw: string | number | null | undefined): number | null {
  if (raw === null || raw === undefined || raw === '') return null
  if (typeof raw === 'number') {
    return isFinite(raw) ? raw : null
  }
  const cleaned = raw
    .toString()
    .trim()
    .replace(/₹/g, '')
    .replace(/,/g, '')
    .replace(/\s/g, '')
  if (cleaned === '' || cleaned === '-' || cleaned.toLowerCase() === 'n/a') return null
  const n = parseFloat(cleaned)
  return isFinite(n) ? n : null
}

// ─── Probabilities ───────────────────────────────────────────────────────────

const PROB_MAP: Record<string, number> = {
  high: 0.75,
  medium: 0.5,
  low: 0.25,
}

/**
 * Normalize probability from:
 *   - "High" / "Medium" / "Low" → 0.75 / 0.5 / 0.25
 *   - "70%" → 0.7
 *   - "0.7" → 0.7
 *   - "70" → 0.7 (if clearly a percentage)
 */
export function normalizeProbability(raw: string | number | null | undefined): ProbabilityValue {
  if (raw === null || raw === undefined || raw === '') return null
  if (typeof raw === 'number') {
    if (!isFinite(raw)) return null
    // If > 1 assume it's already 0-100 scale
    return raw > 1 ? raw / 100 : raw
  }
  const cleaned = raw.toString().trim().toLowerCase()
  if (!cleaned || cleaned === '-') return null
  if (cleaned in PROB_MAP) return PROB_MAP[cleaned]
  const withoutPct = cleaned.replace('%', '')
  const n = parseFloat(withoutPct)
  if (!isFinite(n)) return null
  return cleaned.includes('%') ? n / 100 : n > 1 ? n / 100 : n
}

export function normalizeProbabilityLabel(raw: string | null | undefined): ClosureProbability {
  if (!raw) return null
  const s = raw.trim().toLowerCase()
  if (s === 'high') return 'High'
  if (s === 'medium') return 'Medium'
  if (s === 'low') return 'Low'
  return null
}

// ─── Status normalizers ───────────────────────────────────────────────────────

export function normalizeDealStatus(raw: string | null | undefined): DealStatus {
  if (!raw) return 'Unknown'
  const s = raw.trim().toLowerCase()
  if (s === 'open') return 'Open'
  if (s === 'won' || s === 'closed won') return 'Won'
  if (s === 'lost' || s === 'closed lost') return 'Lost'
  if (s === 'on hold' || s === 'hold') return 'On Hold'
  return 'Unknown'
}

export function normalizeDealStage(raw: string | null | undefined): DealStage {
  if (!raw) return 'Unknown'
  const s = raw.trim()
  const knownStages: DealStage[] = [
    'A. Lead',
    'B. Sales Qualified Leads',
    'C. Presentation',
    'D. Feasibility',
    'E. Proposal/Commercials Sent',
    'F. Negotiations',
    'G. Verbal Confirmation',
    'H. Work Order Received',
    'I. Won',
    'J. Lost',
    'K. Disqualified',
    'M. Projects On Hold',
  ]
  for (const stage of knownStages) {
    if (s.toLowerCase().startsWith(stage.split('.')[0].toLowerCase().trim())) {
      return stage
    }
    if (s === stage) return stage
  }
  return 'Unknown'
}

export function normalizeExecutionStatus(raw: string | null | undefined): ExecutionStatus {
  if (!raw) return 'Unknown'
  const s = raw.trim().toLowerCase()
  if (s.includes('completed') || s === 'complete') return 'Completed'
  if (s.includes('ongoing')) return 'Ongoing'
  if (s.includes('executed until')) return 'Executed until current month'
  if (s.includes('not started')) return 'Not Started'
  if (s.includes('in progress')) return 'In Progress'
  if (s.includes('on hold')) return 'On Hold'
  return 'Unknown'
}

export function normalizeWOStatus(raw: string | null | undefined): WOStatus {
  if (!raw) return 'Unknown'
  const s = raw.trim().toLowerCase()
  if (s === 'closed') return 'Closed'
  if (s === 'open') return 'Open'
  return 'Unknown'
}

export function normalizeInvoiceStatus(raw: string | null | undefined): InvoiceStatus {
  if (!raw) return 'Unknown'
  const s = raw.trim().toLowerCase()
  if (s.includes('fully')) return 'Fully Billed'
  if (s.includes('partially')) return 'Partially Billed'
  if (s.includes('not billed')) return 'Not billed yet'
  return 'Unknown'
}

export function normalizeCollectionStatus(raw: string | null | undefined): CollectionStatus {
  if (!raw) return 'Unknown'
  const s = raw.trim().toLowerCase()
  if (s.includes('collected') || s === 'closed') return 'Collected'
  if (s.includes('partial')) return 'Partial'
  if (s.includes('pending') || s.includes('open')) return 'Pending'
  return 'Unknown'
}

export function normalizeARPriority(raw: string | null | undefined): boolean {
  if (!raw) return false
  return raw.trim().toLowerCase() === 'priority'
}
