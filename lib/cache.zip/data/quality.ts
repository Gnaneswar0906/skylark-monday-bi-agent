import type { DealRecord, WorkOrderRecord, DataQualityReport } from './types'

export function generateDataQualityReport(
  deals: DealRecord[],
  workOrders: WorkOrderRecord[]
): DataQualityReport {
  const dealWarnings: string[] = []
  const woWarnings: string[] = []

  const missingValue = deals.filter((d) => d._missingValue).length
  const missingProbability = deals.filter((d) => d._missingProbability).length
  const missingCloseDate = deals.filter((d) => d._missingCloseDate).length
  const missingCreatedDate = deals.filter((d) => d._missingCreatedDate).length

  if (missingValue > 0)
    dealWarnings.push(`${missingValue} deals are missing deal value — excluded from value-based calculations.`)
  if (missingProbability > 0)
    dealWarnings.push(`${missingProbability} deals are missing closure probability — excluded from weighted pipeline.`)
  if (missingCloseDate > 0)
    dealWarnings.push(`${missingCloseDate} deals are missing a close date — excluded from period-based filtering.`)
  if (missingCreatedDate > 0)
    dealWarnings.push(`${missingCreatedDate} deals are missing a created date.`)

  const woMissingAmount = workOrders.filter((w) => w._missingAmount).length
  const woMissingBilled = workOrders.filter((w) => w._missingBilledValue).length
  const woMissingCollected = workOrders.filter((w) => w._missingCollected).length
  const woMissingReceivable = workOrders.filter((w) => w._missingReceivable).length

  if (woMissingAmount > 0)
    woWarnings.push(`${woMissingAmount} work orders are missing amount — excluded from total billing calculations.`)
  if (woMissingBilled > 0)
    woWarnings.push(`${woMissingBilled} work orders have incomplete billed value information.`)
  if (woMissingCollected > 0)
    woWarnings.push(`${woMissingCollected} work orders have incomplete collection data.`)
  if (woMissingReceivable > 0)
    woWarnings.push(`${woMissingReceivable} work orders are missing receivable amounts.`)

  return {
    deals: {
      total: deals.length,
      missingValue,
      missingProbability,
      missingCloseDate,
      missingCreatedDate,
      warnings: dealWarnings,
    },
    workOrders: {
      total: workOrders.length,
      missingAmount: woMissingAmount,
      missingBilledValue: woMissingBilled,
      missingCollected: woMissingCollected,
      missingReceivable: woMissingReceivable,
      warnings: woWarnings,
    },
  }
}

export function getRelevantQualityWarnings(
  report: DataQualityReport,
  intent: string
): string[] {
  const warnings: string[] = []
  const dealIntents = ['pipeline_health', 'deal_analysis', 'deal_risk', 'stage_analysis', 'sector_performance', 'business_health', 'leadership_update', 'cross_board_analysis']
  const woIntents = ['work_order_performance', 'billing_analysis', 'collections_analysis', 'receivables_analysis', 'business_health', 'leadership_update', 'cross_board_analysis']

  if (dealIntents.includes(intent)) {
    warnings.push(...report.deals.warnings)
  }
  if (woIntents.includes(intent)) {
    warnings.push(...report.workOrders.warnings)
  }
  return warnings
}
