// Canonical data types for the Skylark BI Agent

export type DealStatus = 'Open' | 'Won' | 'Lost' | 'On Hold' | 'Unknown'
export type DealStage =
  | 'A. Lead'
  | 'B. Sales Qualified Leads'
  | 'C. Presentation'
  | 'D. Feasibility'
  | 'E. Proposal/Commercials Sent'
  | 'F. Negotiations'
  | 'G. Verbal Confirmation'
  | 'H. Work Order Received'
  | 'I. Won'
  | 'J. Lost'
  | 'K. Disqualified'
  | 'M. Projects On Hold'
  | 'Unknown'

export type ClosureProbability = 'High' | 'Medium' | 'Low' | null
export type ProbabilityValue = number | null // 0.0 – 1.0

export interface DealRecord {
  id: string
  dealName: string | null
  ownerCode: string | null
  clientCode: string | null
  status: DealStatus
  closeDate: string | null          // ISO date or null
  closureProbabilityLabel: ClosureProbability
  closureProbabilityValue: ProbabilityValue  // derived from label or raw %
  dealValue: number | null          // numeric rupees, null if missing
  tentativeCloseDate: string | null
  dealStage: DealStage
  product: string | null
  sector: string | null
  createdDate: string | null
  // data quality flags
  _missingValue: boolean
  _missingProbability: boolean
  _missingCloseDate: boolean
  _missingCreatedDate: boolean
}

export type ExecutionStatus =
  | 'Completed'
  | 'Ongoing'
  | 'Executed until current month'
  | 'Not Started'
  | 'In Progress'
  | 'On Hold'
  | 'Unknown'

export type WOStatus = 'Open' | 'Closed' | 'Unknown'
export type InvoiceStatus = 'Fully Billed' | 'Partially Billed' | 'Not billed yet' | 'Unknown'
export type CollectionStatus = 'Collected' | 'Partial' | 'Pending' | 'Unknown'
export type BillingStatus = 'Billed' | 'BIlled' | 'Partially Billed' | 'Update Required' | 'Unknown'

export interface WorkOrderRecord {
  id: string
  dealName: string | null
  customerCode: string | null
  serialNumber: string | null
  natureOfWork: string | null
  executionStatus: ExecutionStatus
  dataDeliveryDate: string | null
  poLoiDate: string | null
  documentType: string | null
  probableStartDate: string | null
  probableEndDate: string | null
  bdKamPersonnel: string | null
  sector: string | null
  typeOfWork: string | null
  skylarksoftwarePlatform: string | null

  amountExclGST: number | null
  amountInclGST: number | null
  billedExclGST: number | null
  billedInclGST: number | null
  collectedInclGST: number | null
  toBeBilledExclGST: number | null
  toBeBilledInclGST: number | null
  amountReceivable: number | null
  arPriority: boolean

  invoiceStatus: InvoiceStatus
  expectedBillingMonth: string | null
  actualBillingMonth: string | null
  actualCollectionMonth: string | null
  woStatus: WOStatus
  collectionStatus: CollectionStatus
  collectionDate: string | null
  billingStatus: BillingStatus

  // data quality flags
  _missingAmount: boolean
  _missingBilledValue: boolean
  _missingCollected: boolean
  _missingReceivable: boolean
}

export interface DataQualityReport {
  deals: {
    total: number
    missingValue: number
    missingProbability: number
    missingCloseDate: number
    missingCreatedDate: number
    warnings: string[]
  }
  workOrders: {
    total: number
    missingAmount: number
    missingBilledValue: number
    missingCollected: number
    missingReceivable: number
    warnings: string[]
  }
}

export interface BIResult {
  intent: string
  metrics: Record<string, unknown>
  dataQuality: DataQualityReport
  timestamp: string
}
