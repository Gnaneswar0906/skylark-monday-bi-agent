import type { DataAdapter } from './adapters'
import type { DealRecord, WorkOrderRecord } from './types'
import { fetchBoardItems } from '../monday/boards'
import { mapDealRecord, mapWorkOrderRecord } from '../monday/mapper'

export class MondayDataAdapter implements DataAdapter {
  private dealsBoardId: string
  private workOrdersBoardId: string

  constructor() {
    this.dealsBoardId = process.env.MONDAY_DEALS_BOARD_ID ?? ''
    this.workOrdersBoardId = process.env.MONDAY_WORK_ORDERS_BOARD_ID ?? ''

    if (!this.dealsBoardId) throw new Error('MONDAY_DEALS_BOARD_ID is not configured.')
    if (!this.workOrdersBoardId) throw new Error('MONDAY_WORK_ORDERS_BOARD_ID is not configured.')
  }

  async getDeals(): Promise<DealRecord[]> {
    const { columns, items } = await fetchBoardItems(this.dealsBoardId)
    return items.map((item, i) => mapDealRecord(item, columns, i))
  }

  async getWorkOrders(): Promise<WorkOrderRecord[]> {
    const { columns, items } = await fetchBoardItems(this.workOrdersBoardId)
    return items.map((item, i) => mapWorkOrderRecord(item, columns, i))
  }
}
