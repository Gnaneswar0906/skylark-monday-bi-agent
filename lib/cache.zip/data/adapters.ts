import type { DealRecord, WorkOrderRecord } from './types'

export interface DataAdapter {
  getDeals(): Promise<DealRecord[]>
  getWorkOrders(): Promise<WorkOrderRecord[]>
}
