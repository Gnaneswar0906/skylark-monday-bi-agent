import { GoogleGenerativeAI } from '@google/generative-ai'
import { EXECUTIVE_RESPONSE_SYSTEM_PROMPT } from './prompts'

function getModelName(): string {
  return process.env.LLM_MODEL ?? 'gemini-1.5-flash'
}

/** Format a number in Indian rupee notation */
function formatINR(n: number): string {
  if (n >= 1_00_00_000) return `₹${(n / 1_00_00_000).toFixed(2)}Cr`
  if (n >= 1_00_000) return `₹${(n / 1_00_000).toFixed(1)}L`
  return `₹${Math.round(n).toLocaleString('en-IN')}`
}

function pct(n: number | null | undefined): string {
  if (n === null || n === undefined) return 'N/A'
  return `${(n * 100).toFixed(0)}%`
}

/**
 * Template-based response generator — used when LLM is not configured.
 * Produces structured markdown from the BI data directly.
 */
function templateResponse(
  biData: Record<string, unknown>,
  qualityWarnings: string[]
): string {
  const lines: string[] = []

  // ── Pipeline Health ──
  if (biData.pipeline) {
    const p = biData.pipeline as Record<string, unknown>
    lines.push('## Executive Summary')
    lines.push(`Your pipeline has **${p.openDeals} open deals** with a total pipeline value of **${formatINR(p.pipelineValue as number)}** and a weighted pipeline of **${formatINR(p.weightedPipeline as number)}**.`)
    lines.push('')
    lines.push('## Key Metrics')
    lines.push(`• Total Deals: ${p.totalDeals}`)
    lines.push(`• Open Deals: ${p.openDeals}`)
    lines.push(`• Won Deals: ${p.wonDeals}`)
    lines.push(`• Lost Deals: ${p.lostDeals}`)
    lines.push(`• Pipeline Value: ${formatINR(p.pipelineValue as number)}`)
    lines.push(`• Weighted Pipeline: ${formatINR(p.weightedPipeline as number)}`)
    if (p.averageDealValue) lines.push(`• Average Deal Value: ${formatINR(p.averageDealValue as number)}`)
    lines.push('')

    const stages = p.stageDistribution as Record<string, number>
    if (stages && Object.keys(stages).length > 0) {
      lines.push('## Stage Distribution')
      Object.entries(stages)
        .sort(([, a], [, b]) => b - a)
        .forEach(([stage, count]) => lines.push(`• ${stage}: ${count} deals`))
      lines.push('')
    }
  }

  // ── Sector (cross_board_analysis / sector_performance) ──
  if (biData.sector) {
    const s = biData.sector as Record<string, unknown>
    const deals = s.deals as Record<string, unknown>
    const ops = s.operations as Record<string, unknown>
    const fin = s.finance as Record<string, unknown>

    lines.push(`## Executive Summary — ${s.sector}`)
    lines.push(`${s.sector} has **${deals.open} open deals** with a pipeline of **${formatINR(deals.pipelineValue as number)}**.`)
    lines.push('')
    lines.push('## Sales')
    lines.push(`• Open Deals: ${deals.open} | Won: ${deals.won} | Lost: ${deals.lost}`)
    lines.push(`• Pipeline Value: ${formatINR(deals.pipelineValue as number)}`)
    lines.push(`• Weighted Pipeline: ${formatINR(deals.weightedPipeline as number)}`)
    lines.push('')
    lines.push('## Operations')
    lines.push(`• Total Work Orders: ${ops.totalWorkOrders}`)
    lines.push(`• Completed: ${ops.completed} | Ongoing: ${ops.ongoing} | Not Started: ${ops.notStarted}`)
    lines.push('')
    lines.push('## Financial')
    lines.push(`• Billed: ${formatINR(fin.totalBilled as number)}`)
    lines.push(`• Collected: ${formatINR(fin.totalCollected as number)}`)
    lines.push(`• Receivables: ${formatINR(fin.totalReceivable as number)}`)
  }

  // ── Sector Leaderboard ──
  if (biData.sectorLeaderboard) {
    const lb = biData.sectorLeaderboard as Record<string, unknown>
    const sectors = lb.sectors as Record<string, unknown>[]
    lines.push('## Executive Summary')
    lines.push(`**Top sector by pipeline: ${lb.topSectorByPipeline ?? 'N/A'}** | Top by revenue: ${lb.topSectorByRevenue ?? 'N/A'}`)
    lines.push('')
    lines.push('## Sector Rankings (by Pipeline)')
    sectors.slice(0, 8).forEach((s, i) => {
      const d = s.deals as Record<string, unknown>
      lines.push(`${i + 1}. **${s.sector}** — Pipeline: ${formatINR(d.pipelineValue as number)}, Open Deals: ${d.open}, Weighted: ${formatINR(d.weightedPipeline as number)}`)
    })
  }

  // ── Biggest Deals ──
  if (biData.biggestDeals) {
    const deals = biData.biggestDeals as Record<string, unknown>[]
    lines.push('## Executive Summary')
    lines.push(`Here are your **top ${deals.length} open deals** by deal value:`)
    lines.push('')
    lines.push('## Biggest Deals')
    deals.forEach((d, i) => {
      lines.push(`${i + 1}. **${d.dealName ?? 'Unnamed'}** (${d.sector ?? 'Unknown sector'}) — ${d.dealValue ? formatINR(d.dealValue as number) : 'Value unknown'} | Stage: ${d.dealStage} | Prob: ${d.closureProbabilityLabel ?? 'N/A'}`)
    })
  }

  // ── At-Risk Deals ──
  if (biData.atRiskDeals) {
    const deals = biData.atRiskDeals as Record<string, unknown>[]
    lines.push('## Executive Summary')
    lines.push(`**${deals.length} deals** have been flagged as at-risk based on low probability, missing data, or overdue close dates.`)
    lines.push('')
    lines.push('## At-Risk Deals')
    if (deals.length === 0) {
      lines.push('No deals are currently flagged as at-risk.')
    } else {
      deals.slice(0, 10).forEach((d) => {
        lines.push(`• **${d.dealName ?? 'Unnamed'}** (${d.sector ?? '?'}) — ${d.dealValue ? formatINR(d.dealValue as number) : 'No value'} | Prob: ${d.closureProbabilityLabel ?? 'Missing'} | Close: ${d.closeDate ?? 'No date'}`)
      })
    }
    lines.push('')
    lines.push('## Risk Factors')
    lines.push('• Deals with Low probability indicate low confidence in conversion.')
    lines.push('• Deals past their close date require immediate follow-up.')
    lines.push('• Deals with no probability assigned need attention.')
  }

  // ── Finance / Collections / Receivables ──
  if (biData.finance) {
    const f = biData.finance as Record<string, unknown>
    lines.push('## Executive Summary')
    lines.push(`Total billed: **${formatINR(f.totalBilledExclGST as number)}** | Collected: **${formatINR(f.totalCollected as number)}** | Outstanding: **${formatINR(f.totalReceivable as number)}**`)
    lines.push('')
    lines.push('## Key Metrics')
    lines.push(`• Total Billed (excl. GST): ${formatINR(f.totalBilledExclGST as number)}`)
    lines.push(`• Total Billed (incl. GST): ${formatINR(f.totalBilledInclGST as number)}`)
    lines.push(`• Total Collected: ${formatINR(f.totalCollected as number)}`)
    lines.push(`• Total Receivable: ${formatINR(f.totalReceivable as number)}`)
    lines.push(`• Collection Rate: ${pct(f.collectionRate as number)}`)
    lines.push(`• Billing Rate: ${pct(f.billingRate as number)}`)
    lines.push(`• Collections Gap: ${formatINR(f.collectionsGap as number)}`)
    if (f.priorityReceivableCount) lines.push(`• Priority AR Accounts: ${f.priorityReceivableCount}`)
  }

  if (biData.collections) {
    const c = biData.collections as Record<string, unknown>
    lines.push('## Collections Summary')
    lines.push(`• Total Collected: ${formatINR(c.totalCollected as number)}`)
    lines.push(`• Total Billed: ${formatINR(c.totalBilled as number)}`)
    lines.push(`• Collection Rate: ${pct(c.collectionRate as number)}`)
    lines.push(`• Outstanding Gap: ${formatINR(c.collectionsGap as number)}`)
  }

  if (biData.receivables) {
    const r = biData.receivables as Record<string, unknown>
    const priorityAccounts = r.priorityAccounts as Record<string, unknown>[]
    lines.push('## Receivables Summary')
    lines.push(`• Total Receivable: **${formatINR(r.totalReceivable as number)}**`)
    lines.push(`• Priority Accounts: ${r.priorityCount}`)
    lines.push(`• Outstanding Priority Amount: ${formatINR(r.outstandingPriority as number)}`)
    if (priorityAccounts?.length > 0) {
      lines.push('')
      lines.push('## Priority Accounts')
      priorityAccounts.forEach((a) => {
        lines.push(`• **${a.dealName ?? 'N/A'}** (${a.sector ?? '?'}): ${a.receivable ? formatINR(a.receivable as number) : 'Unknown'}`)
      })
    }
  }

  // ── Business Health ──
  if (biData.businessHealth) {
    const h = biData.businessHealth as Record<string, unknown>
    lines.push('## Executive Summary')
    lines.push(`Overall business health: **${h.overallHealth}** | Sales: ${h.salesHealth} | Operations: ${h.operationalHealth} | Financial: ${h.financialHealth}`)
    lines.push('')
    lines.push('## Health Scores')
    lines.push(`• Overall: ${h.overallHealth}`)
    lines.push(`• Sales Health: ${h.salesHealth}`)
    lines.push(`• Operational Health: ${h.operationalHealth}`)
    lines.push(`• Financial Health: ${h.financialHealth}`)
    lines.push(`• Top Sectors: ${(h.topSectors as string[])?.join(', ') ?? 'N/A'}`)

    const risks = h.risks as string[]
    if (risks?.length > 0) {
      lines.push('')
      lines.push('## Risks / Watch Items')
      risks.forEach((r) => lines.push(`• ${r}`))
    }

    const recs = h.recommendations as string[]
    if (recs?.length > 0) {
      lines.push('')
      lines.push('## Recommended Actions')
      recs.forEach((r) => lines.push(`• ${r}`))
    }
  }

  // ── Leadership Update ──
  if (biData.leadershipUpdate) {
    const lu = biData.leadershipUpdate as Record<string, unknown>
    const sales = lu.sales as Record<string, unknown>
    const ops = lu.operations as Record<string, unknown>
    const fin = lu.financial as Record<string, unknown>
    const risks = lu.keyRisks as string[]
    const attention = lu.leadershipAttention as string[]

    lines.push('# Skylark Drones — Leadership Update')
    lines.push(`*Generated: ${new Date().toLocaleDateString('en-IN', { dateStyle: 'long' })}*`)
    lines.push('')
    lines.push('## Sales')
    lines.push(`• Pipeline: ${formatINR(sales.pipelineValue as number)}`)
    lines.push(`• Weighted Pipeline: ${formatINR(sales.weightedPipeline as number)}`)
    lines.push(`• Open Deals: ${sales.openDeals} | Won: ${sales.wonDeals}`)
    lines.push(`• Top Sector: ${sales.topSector ?? 'N/A'}`)
    lines.push('')
    lines.push('## Operations')
    lines.push(`• Total Work Orders: ${ops.totalWorkOrders}`)
    lines.push(`• Completed: ${ops.completed} | Ongoing: ${ops.ongoing} | Not Started: ${ops.notStarted}`)
    lines.push(`• Completion Rate: ${pct(ops.completionRate as number)}`)
    lines.push('')
    lines.push('## Financial')
    lines.push(`• Billed: ${formatINR(fin.totalBilled as number)}`)
    lines.push(`• Collected: ${formatINR(fin.totalCollected as number)}`)
    lines.push(`• Receivables: ${formatINR(fin.totalReceivable as number)}`)
    lines.push(`• Collection Rate: ${pct(fin.collectionRate as number)}`)
    if (fin.priorityAccountsCount) lines.push(`• Priority AR Accounts: ${fin.priorityAccountsCount}`)
    lines.push('')
    lines.push('## Key Risks')
    risks?.forEach((r, i) => lines.push(`${i + 1}. ${r}`))
    lines.push('')
    lines.push('## Leadership Attention Required')
    attention?.forEach((a, i) => lines.push(`${i + 1}. ${a}`))
  }

  // Data quality warnings
  if (qualityWarnings.length > 0) {
    lines.push('')
    lines.push('## Data Quality Notes')
    qualityWarnings.slice(0, 3).forEach((w) => lines.push(`• ${w}`))
  }

  // If nothing was generated
  if (lines.length === 0) {
    lines.push('## Analysis Complete')
    lines.push('Data retrieved successfully. Please ask a more specific question for detailed insights.')
  }

  return lines.join('\n')
}

import OpenAI from 'openai'

/** Generate an executive-level response from structured BI metrics */
export async function generateExecutiveResponse(
  userQuestion: string,
  biData: Record<string, unknown>,
  qualityWarnings: string[]
): Promise<string> {
  const geminiKey = process.env.LLM_API_KEY
  const openaiKey = process.env.OPENAI_API_KEY
  const nvidiaKey = process.env.NVIDIA_API_KEY

  const prompt = `
User Question: ${userQuestion}

Business Intelligence Data:
${JSON.stringify(biData, null, 2)}

Data Quality Warnings (include relevant ones in your response):
${qualityWarnings.length > 0 ? qualityWarnings.map((w) => `- ${w}`).join('\n') : 'None'}

Please write a concise, executive-level response based on the data above.
`

  // 1. Try Gemini
  if (geminiKey) {
    try {
      const genAI = new GoogleGenerativeAI(geminiKey)
      const model = genAI.getGenerativeModel({
        model: getModelName(),
        systemInstruction: EXECUTIVE_RESPONSE_SYSTEM_PROMPT,
        generationConfig: { temperature: 0.3 },
      })
      const result = await model.generateContent(prompt)
      return result.response.text()
    } catch (err) {
      console.warn('[Response] Gemini failed, falling back...', err)
    }
  }

  // 2. Try OpenAI
  if (openaiKey) {
    try {
      const openai = new OpenAI({ apiKey: openaiKey })
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        temperature: 0.3,
        messages: [
          { role: 'system', content: EXECUTIVE_RESPONSE_SYSTEM_PROMPT },
          { role: 'user', content: prompt }
        ]
      })
      if (completion.choices[0].message.content) {
        return completion.choices[0].message.content
      }
    } catch (err) {
      console.warn('[Response] OpenAI failed, falling back...', err)
    }
  }

  // 3. Try NVIDIA NIM
  if (nvidiaKey) {
    try {
      const nvidia = new OpenAI({ baseURL: 'https://integrate.api.nvidia.com/v1', apiKey: nvidiaKey })
      const completion = await nvidia.chat.completions.create({
        model: 'meta/llama-3.1-8b-instruct',
        temperature: 0.3,
        messages: [
          { role: 'system', content: EXECUTIVE_RESPONSE_SYSTEM_PROMPT },
          { role: 'user', content: prompt }
        ]
      })
      if (completion.choices[0].message.content) {
        return completion.choices[0].message.content
      }
    } catch (err) {
      console.warn('[Response] NVIDIA NIM failed, falling back...', err)
    }
  }

  // 4. Fallback: template-based response
  console.info('[Response] All LLMs failed or not configured — using template-based fallback.')
  return templateResponse(biData, qualityWarnings)
}
