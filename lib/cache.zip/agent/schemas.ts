import { z } from 'zod'

export const QueryIntentSchema = z.object({
  intent: z.enum([
    'pipeline_health',
    'sector_performance',
    'deal_analysis',
    'deal_risk',
    'stage_analysis',
    'work_order_performance',
    'billing_analysis',
    'collections_analysis',
    'receivables_analysis',
    'cross_board_analysis',
    'business_health',
    'leadership_update',
    'data_quality',
    'clarification_required',
  ]),
  sector: z.string().nullable().optional(),
  period: z
    .enum(['current_quarter', 'last_quarter', 'current_year', 'all_time'])
    .nullable()
    .optional(),
  boards: z.array(z.enum(['deals', 'work_orders'])).optional(),
  metrics: z.array(z.string()).optional(),
  clarificationMessage: z.string().nullable().optional(),
  compareWith: z.string().nullable().optional(),
})

export type QueryIntent = z.infer<typeof QueryIntentSchema>

export const ChatMessageSchema = z.object({
  role: z.enum(['user', 'assistant']),
  content: z.string(),
})

export type ChatMessage = z.infer<typeof ChatMessageSchema>
