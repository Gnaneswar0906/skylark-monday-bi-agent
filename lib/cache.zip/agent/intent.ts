import { GoogleGenerativeAI } from '@google/generative-ai'
import { INTENT_SYSTEM_PROMPT } from './prompts'
import { QueryIntentSchema, type QueryIntent } from './schemas'

function getModelName(): string {
  return process.env.LLM_MODEL ?? 'gemini-1.5-flash'
}

const SECTORS = ['mining', 'powerline', 'renewables', 'railways', 'dsp', 'tender', 'energy', 'utilities', 'solar', 'agriculture']

/**
 * Rule-based intent parser — used as fallback when LLM is not configured.
 * Handles common keyword patterns deterministically.
 */
function ruleBasedIntentParse(msg: string): QueryIntent {
  const q = msg.toLowerCase()

  // Detect sector mention
  const mentionedSector = SECTORS.find((s) => q.includes(s))
  const sector = mentionedSector
    ? mentionedSector.charAt(0).toUpperCase() + mentionedSector.slice(1)
    : null

  // Detect period
  const period =
    q.includes('this quarter') || q.includes('current quarter')
      ? 'current_quarter'
      : q.includes('last quarter')
      ? 'last_quarter'
      : q.includes('this year')
      ? 'current_year'
      : null

  // Leadership update
  if (q.includes('leadership') || q.includes('management update') || q.includes('prepare a') || q.includes('board update')) {
    return { intent: 'leadership_update', period, boards: ['deals', 'work_orders'] }
  }

  // Business health
  if (q.includes('business health') || q.includes('overall') || q.includes('assessment') || q.includes('how healthy') || q.includes('health check')) {
    return { intent: 'business_health', sector, boards: ['deals', 'work_orders'] }
  }

  // Sector comparison (compare X and Y)
  const compareMatch = msg.match(/compare\s+(\w+)\s+and\s+(\w+)/i)
  if (compareMatch) {
    const s1 = compareMatch[1].charAt(0).toUpperCase() + compareMatch[1].slice(1).toLowerCase()
    const s2 = compareMatch[2].charAt(0).toUpperCase() + compareMatch[2].slice(1).toLowerCase()
    return { intent: 'cross_board_analysis', sector: s1, compareWith: s2, boards: ['deals', 'work_orders'] }
  }

  // Sector-specific deep dive
  if (sector && (q.includes('how is') || q.includes('performing') || q.includes('performance') || q.includes('sector'))) {
    return { intent: 'cross_board_analysis', sector, boards: ['deals', 'work_orders'] }
  }

  // Pipeline
  if (q.includes('pipeline') || q.includes('funnel') || q.includes('deals this quarter') || q.includes('how are our deals')) {
    if (sector) return { intent: 'sector_performance', sector, boards: ['deals'], period }
    return { intent: 'pipeline_health', period, boards: ['deals'], metrics: ['pipeline_value', 'weighted_pipeline', 'deal_count'] }
  }

  // Biggest / top deals
  if (q.includes('biggest deal') || q.includes('top deal') || q.includes('largest deal') || q.includes('highest value')) {
    return { intent: 'deal_analysis', sector, boards: ['deals'] }
  }

  // At-risk / risky deals
  if (q.includes('at risk') || q.includes('risk') || q.includes('problematic') || q.includes('concern') || q.includes('watch')) {
    return { intent: 'deal_risk', sector, boards: ['deals'] }
  }

  // Receivables
  if (q.includes('receivable') || q.includes('outstanding') || q.includes('unpaid')) {
    return { intent: 'receivables_analysis', sector, boards: ['work_orders'] }
  }

  // Collections
  if (q.includes('collect') || q.includes('payment received') || (q.includes('billed') && q.includes('collected'))) {
    return { intent: 'collections_analysis', sector, boards: ['work_orders'] }
  }

  // Billing
  if (q.includes('bill') || q.includes('invoice') || q.includes('revenue')) {
    return { intent: 'billing_analysis', sector, boards: ['work_orders'] }
  }

  // Work orders / operations
  if (q.includes('work order') || q.includes('execution') || q.includes('project status') || q.includes('operational')) {
    return { intent: 'work_order_performance', sector, boards: ['work_orders'] }
  }

  // Sector leaderboard
  if (q.includes('which sector') || q.includes('best sector') || q.includes('strongest sector') || q.includes('sector has')) {
    return { intent: 'sector_performance', boards: ['deals', 'work_orders'] }
  }

  // Too vague — ask for clarification
  if (q.includes('how are we') || q.includes('how is it') || q.length < 15) {
    return {
      intent: 'clarification_required',
      clarificationMessage: `I can assess:

1. **Sales pipeline** — deal counts, pipeline value, weighted pipeline
2. **Sector performance** — Mining, Powerline, Renewables, and more
3. **Deal analysis** — biggest deals, at-risk deals, stage distribution
4. **Work order execution** — operational status, completion rates
5. **Billing and collections** — billed vs collected, receivables
6. **Overall business health** — cross-board assessment
7. **Leadership update** — full management report

Which would you like me to analyze?`,
    }
  }

  // Default to pipeline
  return { intent: 'pipeline_health', sector, period, boards: ['deals'] }
}

import OpenAI from 'openai'

/** Parse a natural language question into a structured QueryIntent */
export async function parseQueryIntent(userMessage: string): Promise<QueryIntent> {
  const geminiKey = process.env.LLM_API_KEY
  const openaiKey = process.env.OPENAI_API_KEY
  const nvidiaKey = process.env.NVIDIA_API_KEY

  const tryParseJSON = (text: string) => {
    try { return JSON.parse(text) } catch { return null }
  }

  const validateIntent = (parsed: any) => {
    if (!parsed) return null
    const validated = QueryIntentSchema.safeParse(parsed)
    return validated.success ? validated.data : null
  }

  // 1. Try Gemini
  if (geminiKey) {
    try {
      const genAI = new GoogleGenerativeAI(geminiKey)
      const model = genAI.getGenerativeModel({
        model: getModelName(),
        systemInstruction: INTENT_SYSTEM_PROMPT,
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0.1,
        },
      })

      const result = await model.generateContent(userMessage)
      const parsed = tryParseJSON(result.response.text())
      const intent = validateIntent(parsed)
      if (intent) return intent
    } catch (err) {
      console.warn('[Intent] Gemini failed, falling back...', err)
    }
  }

  // 2. Try OpenAI
  if (openaiKey) {
    try {
      const openai = new OpenAI({ apiKey: openaiKey })
      const completion = await openai.chat.completions.create({
        model: 'gpt-4o-mini',
        response_format: { type: 'json_object' },
        temperature: 0.1,
        messages: [
          { role: 'system', content: INTENT_SYSTEM_PROMPT },
          { role: 'user', content: userMessage }
        ]
      })
      const parsed = tryParseJSON(completion.choices[0].message.content || '')
      const intent = validateIntent(parsed)
      if (intent) return intent
    } catch (err) {
      console.warn('[Intent] OpenAI failed, falling back...', err)
    }
  }

  // 3. Try NVIDIA NIM
  if (nvidiaKey) {
    try {
      const nvidia = new OpenAI({ baseURL: 'https://integrate.api.nvidia.com/v1', apiKey: nvidiaKey })
      const completion = await nvidia.chat.completions.create({
        model: 'meta/llama-3.1-8b-instruct',
        response_format: { type: 'json_object' },
        temperature: 0.1,
        messages: [
          { role: 'system', content: INTENT_SYSTEM_PROMPT },
          { role: 'user', content: userMessage }
        ]
      })
      const parsed = tryParseJSON(completion.choices[0].message.content || '')
      const intent = validateIntent(parsed)
      if (intent) return intent
    } catch (err) {
      console.warn('[Intent] NVIDIA NIM failed, falling back...', err)
    }
  }

  // 4. Fallback: rule-based parsing
  console.info('[Intent] All LLMs failed or not configured — using rule-based fallback.')
  return ruleBasedIntentParse(userMessage)
}
