'use client'

import ChatInterface from '@/components/ChatInterface'
import ConnectionStatus from '@/components/ConnectionStatus'

export default function HomePage() {
  return (
    <div
      className="flex flex-col"
      style={{
        height: '100vh',
        background: 'radial-gradient(ellipse at 20% 50%, rgba(79, 70, 229, 0.08) 0%, transparent 60%), radial-gradient(ellipse at 80% 20%, rgba(6, 182, 212, 0.06) 0%, transparent 60%), var(--bg-primary)',
      }}
    >
      {/* Header */}
      <header
        className="flex-shrink-0"
        style={{
          borderBottom: '1px solid var(--border-color)',
          background: 'rgba(10, 10, 31, 0.9)',
          backdropFilter: 'blur(20px)',
          zIndex: 10,
        }}
      >
        <div className="max-w-screen-xl mx-auto px-6 py-4 flex items-center justify-between">
          {/* Brand */}
          <div className="flex items-center gap-3">
            {/* Logo */}
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-lg font-black text-white"
              style={{ background: 'linear-gradient(135deg, #4f46e5, #06b6d4)' }}
            >
              SD
            </div>
            <div>
              <h1 className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>
                Skylark Drones
              </h1>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                Monday.com Business Intelligence Agent
              </p>
            </div>
          </div>

          {/* Badge */}
          <div
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium"
            style={{
              background: 'rgba(99, 102, 241, 0.1)',
              border: '1px solid rgba(99, 102, 241, 0.2)',
              color: 'var(--brand-light)',
            }}
          >
            <span className="status-dot connected" />
            AI-Powered BI Agent
          </div>
        </div>
      </header>

      {/* Main content */}
      <div className="flex-1 overflow-hidden">
        <div className="h-full max-w-screen-xl mx-auto flex" style={{ gap: 0 }}>
          {/* Sidebar */}
          <aside
            className="hidden lg:flex flex-col gap-4 p-5 flex-shrink-0"
            style={{
              width: '280px',
              borderRight: '1px solid var(--border-color)',
              overflowY: 'auto',
            }}
          >
            {/* About */}
            <div className="glass-card p-4">
              <h2 className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: 'var(--text-muted)' }}>
                About
              </h2>
              <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                Ask founder-level questions about your Deals and Work Orders. The agent reads live data from Monday.com
                and provides deterministic, verified business metrics.
              </p>
            </div>

            {/* Connection status */}
            <ConnectionStatus />

            {/* Capabilities */}
            <div className="glass-card p-4">
              <h2 className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: 'var(--text-muted)' }}>
                Capabilities
              </h2>
              <div className="flex flex-col gap-2">
                {[
                  { icon: '📊', label: 'Pipeline Analysis' },
                  { icon: '🏭', label: 'Sector Performance' },
                  { icon: '💼', label: 'Deal Risk Assessment' },
                  { icon: '⚙️', label: 'Work Order Tracking' },
                  { icon: '💰', label: 'Billing & Collections' },
                  { icon: '📋', label: 'Leadership Updates' },
                  { icon: '🔍', label: 'Cross-Board Analysis' },
                  { icon: '⚠️', label: 'Data Quality Reports' },
                ].map((cap) => (
                  <div key={cap.label} className="flex items-center gap-2">
                    <span className="text-sm">{cap.icon}</span>
                    <span className="text-xs" style={{ color: 'var(--text-secondary)' }}>{cap.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Data sources */}
            <div className="glass-card p-4">
              <h2 className="text-xs font-semibold uppercase tracking-wider mb-3" style={{ color: 'var(--text-muted)' }}>
                Data Sources
              </h2>
              {[
                { name: 'Skylark — Deals', icon: '💼' },
                { name: 'Skylark — Work Orders', icon: '📋' },
              ].map((src) => (
                <div key={src.name} className="flex items-center gap-2 py-1">
                  <span className="text-sm">{src.icon}</span>
                  <span className="text-xs font-medium" style={{ color: 'var(--text-secondary)' }}>{src.name}</span>
                </div>
              ))}
            </div>
          </aside>

          {/* Chat area */}
          <main className="flex-1 flex flex-col" style={{ minWidth: 0, overflow: 'hidden' }}>
            <ChatInterface />
          </main>
        </div>
      </div>
    </div>
  )
}
