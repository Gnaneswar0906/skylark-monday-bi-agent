import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: 'Skylark Drones — Business Intelligence Agent',
  description:
    'Conversational BI Agent for Skylark Drones. Get founder-level insights across Deals and Work Orders from Monday.com.',
  keywords: ['business intelligence', 'Skylark Drones', 'Monday.com', 'pipeline analysis', 'drone services'],
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={inter.variable}>
      <body className="antialiased">{children}</body>
    </html>
  )
}
