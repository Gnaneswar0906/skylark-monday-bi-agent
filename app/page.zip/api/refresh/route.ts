import { NextResponse } from 'next/server'
import { invalidateCache, getLastRefreshTime } from '@/lib/cache'
import { getAdapter, getDataWithCache } from '@/lib/cache'

export async function POST() {
  try {
    invalidateCache()
    const adapter = await getAdapter()
    await getDataWithCache(adapter) // Prefetch fresh data
    return NextResponse.json({
      success: true,
      message: 'Data refreshed successfully.',
      lastRefresh: getLastRefreshTime(),
    })
  } catch (err) {
    console.error('[/api/refresh] Error:', err)
    return NextResponse.json(
      { success: false, message: "Couldn't refresh data. Please try again." },
      { status: 500 }
    )
  }
}
