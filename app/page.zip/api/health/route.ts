import { NextResponse } from 'next/server'
import { testConnection } from '@/lib/monday/client'
import { getLastRefreshTime, isCacheValid } from '@/lib/cache'

export async function GET() {
  const dataSource = process.env.DATA_SOURCE ?? 'monday'
  const hasMondayConfig = !!(
    process.env.MONDAY_API_TOKEN &&
    process.env.MONDAY_DEALS_BOARD_ID &&
    process.env.MONDAY_WORK_ORDERS_BOARD_ID
  )

  let mondayStatus: 'connected' | 'disconnected' | 'not_configured' = 'not_configured'

  if (hasMondayConfig) {
    const result = await testConnection()
    mondayStatus = result.ok ? 'connected' : 'disconnected'
  }

  return NextResponse.json({
    dataSource,
    monday: {
      status: mondayStatus,
      dealsBoard: hasMondayConfig ? 'configured' : 'not_configured',
      workOrdersBoard: hasMondayConfig ? 'configured' : 'not_configured',
    },
    cache: {
      valid: isCacheValid(),
      lastRefresh: getLastRefreshTime(),
    },
    llm: {
      configured: !!(process.env.LLM_API_KEY || process.env.OPENAI_API_KEY || process.env.NVIDIA_API_KEY),
      model: process.env.LLM_API_KEY ? (process.env.LLM_MODEL ?? 'gemini-1.5-flash') 
           : process.env.OPENAI_API_KEY ? 'gpt-4o-mini'
           : process.env.NVIDIA_API_KEY ? 'meta/llama-3.1-70b-instruct'
           : 'None (Fallback)',
    },
  })
}
