import { NextRequest, NextResponse } from 'next/server'
import { parseQueryIntent } from '@/lib/agent/intent'
import { generateExecutiveResponse } from '@/lib/agent/response'
import { getAdapter, getDataWithCache, getLastRefreshTime } from '@/lib/cache'
import { generateDataQualityReport, getRelevantQualityWarnings } from '@/lib/data/quality'
import { calculatePipeline, filterDealsByQuarter, filterDealsBySector } from '@/lib/analytics/pipeline'
import { calculateFinance, filterWorkOrdersBySector } from '@/lib/analytics/finance'
import { calculateWorkOrders } from '@/lib/analytics/workorders'
import { getBiggestDeals, getAtRiskDeals } from '@/lib/analytics/deals'
import { analyzeSector, buildSectorLeaderboard } from '@/lib/analytics/sectors'
import { calculateBusinessHealth } from '@/lib/analytics/health'
import { generateLeadershipUpdate } from '@/lib/analytics/leadership'
import type { QueryIntent } from '@/lib/agent/schemas'
import type { DealRecord, WorkOrderRecord } from '@/lib/data/types'
import { getQuarter, getYear } from 'date-fns'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const userMessage: string = body.message ?? ''

    if (!userMessage.trim()) {
      return NextResponse.json({ error: 'Message is required.' }, { status: 400 })
    }

    // 1. Parse intent
    const intent = await parseQueryIntent(userMessage)

    // Handle clarification
    if (intent.intent === 'clarification_required') {
      return NextResponse.json({
        response: intent.clarificationMessage ?? `I can assess:

1. **Sales pipeline** — deal counts, pipeline value, weighted pipeline
2. **Sector performance** — Mining, Powerline, Renewables, and more
3. **Deal analysis** — biggest deals, at-risk deals, stage distribution
4. **Work order execution** — operational status, completion rates
5. **Billing and collections** — billed vs collected, receivables
6. **Overall business health** — cross-board assessment
7. **Leadership update** — full management report

Which would you like me to analyze?`,
        intent: intent.intent,
        dataQuality: null,
        timestamp: new Date().toISOString(),
        lastRefresh: getLastRefreshTime(),
      })
    }

    // 2. Fetch data
    const adapter = await getAdapter()
    const { deals, workOrders } = await getDataWithCache(adapter)

    // 3. Generate data quality report
    const qualityReport = generateDataQualityReport(deals, workOrders)
    const qualityWarnings = getRelevantQualityWarnings(qualityReport, intent.intent)

    // 4. Run deterministic analytics based on intent
    const biData = await runAnalytics(intent, deals, workOrders)

    // 5. Generate executive response
    const response = await generateExecutiveResponse(userMessage, biData, qualityWarnings)

    return NextResponse.json({
      response,
      intent: intent.intent,
      dataQuality: qualityReport,
      metrics: biData,
      timestamp: new Date().toISOString(),
      lastRefresh: getLastRefreshTime(),
    })
  } catch (err) {
    console.error('[/api/chat] Error:', err)
    const message = (err as Error).message ?? 'Unknown error'

    // Don't expose internal error details to client
    return NextResponse.json(
      {
        response: "I couldn't retrieve the latest data. Please try again in a moment.",
        error: process.env.NODE_ENV === 'development' ? message : 'Internal server error',
      },
      { status: 500 }
    )
  }
}

async function runAnalytics(
  intent: QueryIntent,
  deals: DealRecord[],
  workOrders: WorkOrderRecord[]
): Promise<Record<string, unknown>> {
  // Apply period filter
  let filteredDeals = deals
  const now = new Date()
  if (intent.period === 'current_quarter') {
    filteredDeals = filterDealsByQuarter(deals, {
      year: getYear(now),
      quarter: getQuarter(now),
    })
  } else if (intent.period === 'last_quarter') {
    const lastQ = getQuarter(now) === 1 ? 4 : getQuarter(now) - 1
    const lastQYear = getQuarter(now) === 1 ? getYear(now) - 1 : getYear(now)
    filteredDeals = filterDealsByQuarter(deals, { year: lastQYear, quarter: lastQ })
  }

  switch (intent.intent) {
    case 'pipeline_health': {
      const pipeline = calculatePipeline(filteredDeals)
      return { pipeline, period: intent.period }
    }

    case 'sector_performance': {
      if (intent.sector) {
        const summary = analyzeSector(intent.sector, deals, workOrders)
        return { sector: summary }
      } else {
        const leaderboard = buildSectorLeaderboard(deals, workOrders)
        return { sectorLeaderboard: leaderboard }
      }
    }

    case 'deal_analysis': {
      const biggest = getBiggestDeals(filteredDeals, 10)
      const pipeline = calculatePipeline(filteredDeals)
      return { biggestDeals: biggest, pipeline }
    }

    case 'deal_risk': {
      const atRisk = getAtRiskDeals(filteredDeals)
      return { atRiskDeals: atRisk, count: atRisk.length }
    }

    case 'stage_analysis': {
      const pipeline = calculatePipeline(filteredDeals)
      return { stageDistribution: pipeline.stageDistribution, pipeline }
    }

    case 'work_order_performance': {
      const sector = intent.sector
      const scopedWOs = sector ? filterWorkOrdersBySector(workOrders, sector) : workOrders
      const ops = calculateWorkOrders(scopedWOs)
      return { operations: ops, sector: sector ?? 'All' }
    }

    case 'billing_analysis': {
      const sector = intent.sector
      const scopedWOs = sector ? filterWorkOrdersBySector(workOrders, sector) : workOrders
      const finance = calculateFinance(scopedWOs)
      return { finance, sector: sector ?? 'All' }
    }

    case 'collections_analysis': {
      const sector = intent.sector
      const scopedWOs = sector ? filterWorkOrdersBySector(workOrders, sector) : workOrders
      const finance = calculateFinance(scopedWOs)
      return {
        collections: {
          totalCollected: finance.totalCollected,
          totalBilled: finance.totalBilledInclGST,
          collectionRate: finance.collectionRate,
          collectionsGap: finance.collectionsGap,
          statusDistribution: finance.collectionStatusDistribution,
        },
      }
    }

    case 'receivables_analysis': {
      const sector = intent.sector
      const scopedWOs = sector ? filterWorkOrdersBySector(workOrders, sector) : workOrders
      const finance = calculateFinance(scopedWOs)
      const priorityWOs = scopedWOs.filter((w) => w.arPriority)
      return {
        receivables: {
          totalReceivable: finance.totalReceivable,
          priorityCount: finance.priorityReceivableCount,
          outstandingPriority: finance.outstandingPriority,
          priorityAccounts: priorityWOs.slice(0, 10).map((w) => ({
            dealName: w.dealName,
            sector: w.sector,
            receivable: w.amountReceivable,
          })),
        },
      }
    }

    case 'cross_board_analysis': {
      const sector = intent.sector
      if (sector) {
        const summary = analyzeSector(sector, deals, workOrders)
        // Also handle compareWith
        if (intent.compareWith) {
          const comparison = analyzeSector(intent.compareWith, deals, workOrders)
          return { primary: summary, comparison, sector, compareWith: intent.compareWith }
        }
        return { sector: summary }
      }
      const health = calculateBusinessHealth(deals, workOrders)
      return { businessHealth: health }
    }

    case 'business_health': {
      const health = calculateBusinessHealth(deals, workOrders)
      return { businessHealth: health }
    }

    case 'leadership_update': {
      const update = generateLeadershipUpdate(deals, workOrders)
      return { leadershipUpdate: update }
    }

    case 'data_quality': {
      const report = generateDataQualityReport(deals, workOrders)
      return { dataQuality: report }
    }

    default:
      return { message: 'Unknown intent' }
  }
}
